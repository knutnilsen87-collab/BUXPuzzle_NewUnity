# Document Priority and Source of Truth

## Highest priority

1. PRD_Product_Requirements_Document.md
2. Functional_Specification.md
3. Game_Mechanics_Tile_Specification.md
4. Level_Progression_Difficulty_Model.md
5. Technical_Architecture_Spec.md
6. Acceptance_Criteria.md

## Conflict rule

If documents conflict:
1. Use the PRD for product intent.
2. Use Game Mechanics spec for tile behavior.
3. Use Technical Architecture for implementation boundaries.
4. Use QA Acceptance Criteria for release decisions.

## Deprecated wording

Any inherited template reference to prototype should be interpreted as "full release scope" for this project.
