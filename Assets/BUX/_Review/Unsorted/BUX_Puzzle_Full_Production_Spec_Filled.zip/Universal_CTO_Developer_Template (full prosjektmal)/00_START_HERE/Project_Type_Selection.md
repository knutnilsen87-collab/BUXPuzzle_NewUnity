# Project Type Selection

Selected type:
- Mobile game
- Casual puzzle / match-3
- Social competitive mode
- Cosmetics and meta-progression
- Live events and daily content

Active optional modules:
- Mobile App Module
- Backend API Module
- Marketplace/Ecosystem Module only for app stores/IAP
- Data/ML Module only for analytics and level balancing, not AI gameplay
- Enterprise Security Module not required
- Desktop Plugin Module not required
- AI Agent Module not required for the shipped game
