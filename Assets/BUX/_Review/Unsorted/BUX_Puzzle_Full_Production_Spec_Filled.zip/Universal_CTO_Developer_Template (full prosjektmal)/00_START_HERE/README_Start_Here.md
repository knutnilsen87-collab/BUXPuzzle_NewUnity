# Start Here — BUX Puzzle

BUX Puzzle is a full-featured cozy forest match-3 mobile game built around a polished level journey, fair same-board friend challenges, cosmetic companion customization, and long-term Bear Village progression. The game uses an existing match-3 engine where the BoardEngine remains authoritative, while presentation, companion reactions, rewards, cosmetics, social challenges and live/event systems expand around it without weakening core gameplay fairness.

The product is not planned as an prototype. The planned deliverable is a complete, production-ready release with core gameplay, progression, social competition, economy, cosmetics, QA gates, analytics and operational readiness.


## How to use this package

Read in this order:
1. Project profile and executive summary.
2. PRD and functional specification.
3. Game mechanics and tile specification.
4. Technical architecture.
5. QA and release gates.
6. CTO/developer handoff.

## Non-negotiables

Core product principles:
1. The core board must feel fair, readable and satisfying before additional systems matter.
2. Same-board challenges must be deterministic: same seed, same board, same objective, same rules.
3. Cosmetics must not provide gameplay advantage in fair/ranked modes.
4. Companion reactions must respond to gameplay, never control gameplay.
5. Economy must reward skill, consistency and social play without forcing pay-to-win.
6. New tiles must teach one new idea at a time.
7. Difficulty should increase through interesting constraints, not arbitrary move starvation.
8. Full release means complete journey, social loop, rewards loop, QA coverage and live-ready content pipeline.


## Current asset foundation

Existing BUX2 asset set:

Board/background/UI:
- board_cell_brown.png
- board_corner_decoration_top_left.png
- board_empty_area.png
- board_inner_grid_surface.png
- dark_overlay_vignette.png
- level_background_berry_village.png
- level_background_calm_forest.png
- level_background_magic_clearing.png
- level_background_soft_blurred.png
- main_forest_background.png
- wooden_board_frame.png
- goal_panel.png
- level_panel.png
- moves_left_panel.png
- score_panel.png
- menu_button.png
- settings_button.png
- info_button.png
- bux_puzzle_logo.png

Tiles:
- red_berry_tile.png
- blueberry_tile.png
- green_leaf_tile.png
- pink_flower_tile.png
- white_daisy_tile.png
- mushroom_tile.png
- acorn_tile.png
- basket_tile.png
- honey_pot_tile.png
- bear_head_tile.png
- bee_tile.png
- moss_patch_tile.png
- covered_moss_tile.png
- berry_bomb_tile.png
- striped_berry_rocket_tile.png
- rainbow_blast_orb_tile.png
- rainbow_flower_tile.png
- super_berry_booster_tile.png
- shovel_booster_tile.png
