# Project Profile Card

| Field | Value |
|---|---|
| Product name | BUX Puzzle |
| Category | Cozy forest match-3 mobile game |
| Platforms | iOS and Android first |
| Engine assumption | Existing match-3 engine, likely Unity/C# from current code references |
| Release strategy | Complete full release, not prototype-first |
| Signature feature | Fair same-board friend challenges |
| Meta progression | Bear Village + companion wardrobe |
| Visual theme | Cozy forest, berries, honey, moss, magic clearing |
| Primary audience | Casual puzzle players who enjoy cozy progression and light competition |
| Secondary audience | Social/competitive casual players who enjoy beating friends |
| Monetization direction | Fair economy, boosters, cosmetics, optional purchases; no pay-to-win in fair modes |
| Primary risk | Too much feature scope before core gameplay is polished |
| Main quality target | Candy Crush-level readability + cozy companion identity + fair competitive hook |
