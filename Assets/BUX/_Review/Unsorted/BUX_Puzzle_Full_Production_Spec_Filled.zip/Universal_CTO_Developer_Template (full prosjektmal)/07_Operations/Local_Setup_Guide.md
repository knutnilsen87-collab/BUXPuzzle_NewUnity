# Local Setup Guide

## Assumptions

- Unity project exists or will be created from current game repo.
- Existing match-3 engine is already present.
- Backend may be local mock until service is implemented.

## Developer setup

1. Clone repo.
2. Open Unity version specified by project.
3. Import BUX2 assets into approved folder structure.
4. Run BoardEngine unit tests.
5. Open gameplay test scene.
6. Verify sample level loads.
7. Verify logs contain no errors.

## Asset import structure

Assets/Game/Art/BUX2/Board
Assets/Game/Art/BUX2/Tiles
Assets/Game/Art/BUX2/UI
Assets/Game/Presentation/Tiles/Profiles
Assets/Game/Configs/Levels
Assets/Game/Configs/Rewards
Assets/Game/Configs/Cosmetics
