# CI/CD Runbook

## CI checks

- Compile.
- Unit tests.
- Determinism tests.
- Config validation.
- Addressable/asset validation.
- Static analysis/linting if configured.
- Build smoke test.

## Release builds

- Version bump.
- Config freeze.
- Backend compatibility check.
- Store build generation.
- Smoke test on devices.
- Upload to test track.
- QA sign-off.
- Production rollout staged.
