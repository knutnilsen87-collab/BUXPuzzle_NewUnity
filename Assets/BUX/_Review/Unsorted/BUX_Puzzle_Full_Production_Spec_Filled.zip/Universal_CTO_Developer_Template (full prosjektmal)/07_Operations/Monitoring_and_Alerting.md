# Monitoring and Alerting

## Monitor

- crash rate
- ANR rate
- API error rate
- challenge submission failures
- leaderboard failures
- purchase validation failures
- economy grant anomalies
- level fail spikes
- event config fetch failures

## Alerts

Critical:
- crash spike
- backend unavailable
- economy duplication
- challenge validation broken

High:
- event config invalid
- level win rate collapse
- purchase validation errors
