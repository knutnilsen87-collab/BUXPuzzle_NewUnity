# Observability Minimum Contract

Every release must provide:
- app version
- config version
- scoring version
- level version
- challenge version
- event version
- error logs with non-sensitive context
- analytics event health dashboard

Never log secrets, payment tokens or private contact data.
