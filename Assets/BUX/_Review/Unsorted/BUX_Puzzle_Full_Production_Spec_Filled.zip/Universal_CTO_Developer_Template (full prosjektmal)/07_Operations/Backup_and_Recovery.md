# Backup and Recovery

## Backup

- User profiles backed up by backend provider.
- Challenge records retained through expiry + audit period.
- Economy transactions stored append-only where possible.
- Config versions archived.

## Recovery

- Restore user profile from latest valid cloud save.
- Regrant missing server-authoritative rewards through transaction logs.
- Disable broken event via remote config.
- Roll back level config by version.
