# Incident Response

## Severity examples

S1:
- game cannot launch
- progress loss
- economy exploit
- challenge system corrupts leaderboards

S2:
- event broken
- high crash on specific device
- leaderboard delayed

S3:
- cosmetic visual bug
- minor copy issue

## Response flow

Detect → Triage → Mitigate → Communicate → Fix → Validate → Postmortem.

## Emergency controls

- disable event
- disable challenge submissions
- hide leaderboard
- disable broken level
- disable purchase offer
