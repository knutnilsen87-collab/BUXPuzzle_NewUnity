# CTO / Developer Handoff

## Project

BUX Puzzle — complete cozy forest match-3 mobile game.

## Product summary

BUX Puzzle is a full-featured cozy forest match-3 mobile game built around a polished level journey, fair same-board friend challenges, cosmetic companion customization, and long-term Bear Village progression. The game uses an existing match-3 engine where the BoardEngine remains authoritative, while presentation, companion reactions, rewards, cosmetics, social challenges and live/event systems expand around it without weakening core gameplay fairness.

The product is not planned as an prototype. The planned deliverable is a complete, production-ready release with core gameplay, progression, social competition, economy, cosmetics, QA gates, analytics and operational readiness.


## Existing assets

Existing BUX2 asset set:

Board/background/UI:
- board_cell_brown.png
- board_corner_decoration_top_left.png
- board_empty_area.png
- board_inner_grid_surface.png
- dark_overlay_vignette.png
- level_background_berry_village.png
- level_background_calm_forest.png
- level_background_magic_clearing.png
- level_background_soft_blurred.png
- main_forest_background.png
- wooden_board_frame.png
- goal_panel.png
- level_panel.png
- moves_left_panel.png
- score_panel.png
- menu_button.png
- settings_button.png
- info_button.png
- bux_puzzle_logo.png

Tiles:
- red_berry_tile.png
- blueberry_tile.png
- green_leaf_tile.png
- pink_flower_tile.png
- white_daisy_tile.png
- mushroom_tile.png
- acorn_tile.png
- basket_tile.png
- honey_pot_tile.png
- bear_head_tile.png
- bee_tile.png
- moss_patch_tile.png
- covered_moss_tile.png
- berry_bomb_tile.png
- striped_berry_rocket_tile.png
- rainbow_blast_orb_tile.png
- rainbow_flower_tile.png
- super_berry_booster_tile.png
- shovel_booster_tile.png


## Architecture recommendation

Reuse the existing match-3 engine if:
- BoardEngine is authoritative.
- ResolveTrace exists or can be added.
- Presentation can subscribe to resolved events.
- Seeded deterministic generation can be guaranteed.
- Tile mechanics can be config-driven.

Do not rewrite the engine unless:
- gameplay logic is tangled with animation,
- resolution is not deterministic,
- the code cannot support testing,
- specials/blockers/objectives require unsafe hacks.

## Build priorities

1. Engine determinism and tests.
2. Tile/objective/blocker/special rules.
3. Visual profile and animation system.
4. Level progression and difficulty.
5. Companion reaction system.
6. Rewards/economy.
7. Same-board challenge.
8. Backend validation.
9. Bear Village and wardrobe.
10. Full QA and release hardening.

## Critical implementation rule

BoardEngine owns gameplay. Presentation reacts. Companion reacts. Economy grants from resolved outcomes. Backend validates social/ranked outcomes.

## Key docs

- `02_Product/PRD_Product_Requirements_Document.md`
- `02_Product/Game_Mechanics_Tile_Specification.md`
- `02_Product/Social_Challenge_and_Game_Modes.md`
- `02_Product/Companion_Cosmetics_and_Bear_Village.md`
- `04_Technical/Technical_Architecture_Spec.md`
- `06_QA/Acceptance_Criteria.md`
