# Codex Production Prompt

Use this prompt when handing the game repo to a coding agent.

```text
You are working on BUX Puzzle, a full-release cozy forest match-3 mobile game.

Goal:
Implement the complete production architecture and systems described in the docs package.

Highest priority:
1. Reuse the existing match-3 engine if it has a clean BoardEngine/presentation separation.
2. Keep BoardEngine authoritative and deterministic.
3. Do not move gameplay rules into animation or UI code.
4. Implement tile mechanics using config-driven rules.
5. Implement same-board friend challenges with seed/config/scoring versioning.
6. Implement Bear companion reactions as presentation-only.
7. Implement wardrobe/cosmetics without gameplay power.
8. Implement economy through a central RewardService.
9. Add tests for board resolution, specials, blockers, objectives, challenge determinism and rewards.

Do not:
- rewrite the whole engine without proving it is necessary
- add pay-to-win mechanics to fair challenge modes
- make cosmetics affect gameplay
- use non-deterministic random calls in challenge-resolved logic
- make animations mutate board state
- make unrelated refactors

Read these docs first:
- docs/02_Product/PRD_Product_Requirements_Document.md
- docs/02_Product/Game_Mechanics_Tile_Specification.md
- docs/02_Product/Social_Challenge_and_Game_Modes.md
- docs/02_Product/Companion_Cosmetics_and_Bear_Village.md
- docs/04_Technical/Technical_Architecture_Spec.md
- docs/06_QA/Acceptance_Criteria.md

First task:
Audit the existing repo and report:
- current engine structure
- files owning board state
- files owning visual state
- where randomness happens
- how scoring/objectives are implemented
- how specials/blockers are represented
- whether deterministic same-board challenge is currently feasible
- safest first 10 implementation PRs

Before making code changes:
- show file plan
- show risk level
- show tests to run
- keep patch isolated
```
