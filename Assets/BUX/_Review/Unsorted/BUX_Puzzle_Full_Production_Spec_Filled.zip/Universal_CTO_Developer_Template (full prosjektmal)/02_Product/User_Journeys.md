# User Journeys

## First session journey

1. Player opens game.
2. Bear welcomes player.
3. Player plays first basic match level.
4. Bear reacts to first match and win.
5. Player receives coins/stars.
6. Bear walks to next map node.
7. Player unlocks wardrobe preview after a few levels.
8. Player sees future challenge/social feature teaser when appropriate.

## Friend challenge journey

1. Player completes a level with good score.
2. Prompt: "Challenge a friend on the same board?"
3. Player chooses friend/share link.
4. Friend accepts challenge.
5. Friend plays same seed.
6. Result screen compares score/time/moves.
7. Winner receives trophies/challenge chest progress.
8. Rematch CTA appears.

## Cosmetic journey

1. Player earns cosmetic shards.
2. Wardrobe notification appears.
3. Player opens Bear Wardrobe.
4. Player previews/equips item.
5. Bear appears with item on map and challenge leaderboard.

## Daily journey

1. Player claims daily reward.
2. Plays Daily Puzzle.
3. Checks pending challenges.
4. Plays main journey.
5. Spends stars in Bear Village.
