# Rewards, Economy and Monetization Specification

## Economy goals

The economy should:
- reward skill and consistency
- support replay and social challenges
- give cosmetics emotional value
- avoid pay-to-win in fair challenges
- give players useful choices without making levels feel impossible without boosters

## Currencies

Coins:
- Earned from levels, daily rewards, challenges, chests.
- Used for basic boosters, retries, simple cosmetics and Bear Village decorations.

Stars:
- Earned from level performance.
- Used for Bear Village building milestones and world unlock decoration gates.

Trophies:
- Earned from friend challenges, daily duels and weekly leagues.
- Used for ranked cosmetics, badges and prestige tiers.

Honey Tokens:
- Event currency.
- Earned during Honey Harvest and similar events.
- Used for limited cosmetics and event chests.

Cosmetic Shards:
- Earned from daily streaks, perfect clears, events and chests.
- Used to unlock wardrobe items.

Booster Fragments:
- Earned through play.
- Combine fragments into boosters.
- Keeps booster economy generous without direct pay pressure.

## Reward sources

- Level complete.
- 3-star completion.
- Perfect Clear.
- Daily Puzzle.
- Friend Challenge win.
- Friend Challenge participation.
- Weekly League placement.
- Event tasks.
- Bear Village milestones.
- Daily streak.

## Reward sinks

- Shovel booster.
- Pre-level Bomb booster.
- Pre-level Rocket booster.
- Extra moves after fail.
- Retry preserving streak.
- Bear cosmetics.
- Board frames.
- Victory dances.
- Map trails.
- Bear Village decorations.
- Event cosmetic unlocks.

## Cosmetics must not affect gameplay

Forbidden:
- hats giving extra moves
- outfits increasing score multiplier
- paid skins increasing special spawn chance
- challenge-only power boosts

Allowed:
- victory pose
- idle animation
- map trail
- profile badge
- board frame
- companion outfit
- challenge emote

## Chest design

Chests:
- Small Chest: coins + booster fragment.
- Star Chest: opened after collecting stars.
- Friend Chest: challenge rewards.
- Honey Chest: event currency rewards.
- Perfect Chest: perfect-clear progression.

Rules:
- Always show minimum guaranteed reward.
- Avoid gambling-like presentation.
- Do not gate essential progression behind random drops.
