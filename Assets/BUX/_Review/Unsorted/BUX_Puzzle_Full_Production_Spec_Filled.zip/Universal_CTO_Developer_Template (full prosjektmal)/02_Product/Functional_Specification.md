# Functional Specification

## Functional modules

1. Core Board
   - swap input
   - legal move detection
   - match resolution
   - cascades
   - gravity
   - specials
   - blockers
   - objectives
   - scoring

2. Level System
   - world map
   - level catalog
   - objectives
   - move limits
   - tile spawn tables
   - difficulty tags

3. Rewards and Economy
   - coins
   - stars
   - trophies
   - event tokens
   - cosmetic shards
   - booster fragments
   - chests

4. Social Challenge
   - same-board challenge creation
   - deterministic challenge seed
   - friend invite/share
   - score submission
   - result comparison
   - rematch

5. Companion
   - board-side reactions
   - map movement
   - wardrobe
   - cosmetics inventory
   - challenge avatar display

6. Bear Village
   - buildings
   - upgrades
   - decorations
   - reward unlocks

7. Live/Events
   - daily puzzle
   - weekly league
   - seasonal event
   - event shops/rewards

8. Backend
   - profile
   - cloud save
   - leaderboard
   - challenge validation
   - event config

## Core gameplay requirements

- Swaps only resolve if they produce a legal match or activate a valid special.
- Invalid swaps animate out and revert.
- Board locks input during resolve/cascade.
- Every resolve produces a trace consumable by animation, scoring, objectives and companion.
- Tile spawn is deterministic for seeded challenges.
- Shuffle only happens if no valid moves exist, and it must be fair/visible.

## Tile mechanics

See `Game_Mechanics_Tile_Specification.md`.

## Social challenge requirements

- Player can challenge friend after completing eligible level.
- Challenge includes seed, rules, level config version and scoring version.
- Ranked/fair challenge disables unequal boosters.
- Casual challenge may allow boosters but is tagged as casual.
- Result screen explains winner using score breakdown.

## Companion requirements

- Companion is visible beside board on standard gameplay screen.
- Companion reacts to meaningful gameplay events.
- Companion never blocks input or changes engine state.
- Companion outfit appears on board side, map and leaderboard avatar.
- Wardrobe items are cosmetic-only.

## Economy requirements

- Rewards are granted by a central RewardService.
- All currency changes are auditable.
- Premium purchase, if used, cannot bypass fair challenge rules.
- Chests have guaranteed minimum rewards.

## Accessibility requirements

- Reduced motion setting.
- Board readable without relying on color alone.
- Tap targets sized for mobile.
- Effects must not obscure critical tile states.
- Text and icons should remain legible over backgrounds.
