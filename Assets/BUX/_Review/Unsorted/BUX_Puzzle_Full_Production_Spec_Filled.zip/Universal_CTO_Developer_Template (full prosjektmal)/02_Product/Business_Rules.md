# Business Rules

Core product principles:
1. The core board must feel fair, readable and satisfying before additional systems matter.
2. Same-board challenges must be deterministic: same seed, same board, same objective, same rules.
3. Cosmetics must not provide gameplay advantage in fair/ranked modes.
4. Companion reactions must respond to gameplay, never control gameplay.
5. Economy must reward skill, consistency and social play without forcing pay-to-win.
6. New tiles must teach one new idea at a time.
7. Difficulty should increase through interesting constraints, not arbitrary move starvation.
8. Full release means complete journey, social loop, rewards loop, QA coverage and live-ready content pipeline.


## Core board rules

- BoardEngine is authoritative.
- Presentation does not alter gameplay state.
- Scoring and objectives only update from resolved engine events.
- Same-board challenge uses deterministic seeds.
- Challenge/ranked scoring must be versioned.

## Rewards rules

- A reward is granted only through RewardService.
- Full reward grants are logged locally and synced when online.
- Cosmetics never grant gameplay power.
- Booster usage is disabled or normalized in fair challenge modes.
- Participation rewards must be smaller than win rewards but never zero for meaningful challenge completion.

## Progression rules

- New mechanics are introduced gradually.
- Main journey should not require paid boosters.
- Hard levels must be labeled or naturally signposted.
- World unlocks depend on progress, stars or story state, not random chance.

## Social rules

- Same-board challenges expire after configured duration.
- Expired challenges can still show result history but not accept new attempts.
- Friend challenge scores include booster policy tag.
- Ranked/fair results require server validation.

## Companion rules

- Companion reactions cannot delay board resolution.
- Companion wardrobe is cosmetic.
- Companion challenge avatar displays equipped items.
- Bear Head tile mechanic is separate from companion system.
