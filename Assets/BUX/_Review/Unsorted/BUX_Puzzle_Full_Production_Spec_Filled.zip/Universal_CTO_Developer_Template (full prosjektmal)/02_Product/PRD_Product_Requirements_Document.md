# Product Requirements Document (PRD)

## Product definition

BUX Puzzle is a full-release cozy forest match-3 mobile game with a deterministic same-board social challenge system, a reactive Bear companion, cosmetic wardrobe, Bear Village meta-progression, daily puzzles, weekly leagues and seasonal events.

## Problem statement

Many match-3 games are polished but feel generic, solitary or pay-to-win. BUX Puzzle should create a more personal and fair experience: players progress through cozy forest levels, personalize a companion bear, and challenge friends on exactly the same board.

## Jobs to be done

- As a casual player, I want fun and clear match-3 levels so I can relax and make progress.
- As a competitive player, I want to challenge friends fairly so wins feel earned.
- As a collector, I want cosmetics and village upgrades so my progress feels personal.
- As a returning player, I want daily puzzles, events and rewards so I have a reason to come back.
- As a completionist, I want stars, perfect clears and leaderboards so I can master levels.

## Users

Primary:
- Casual mobile puzzle players.
- Players who like cozy, cute, forest-themed games.
- Players who enjoy light competition with friends.

Secondary:
- Completionists.
- Cosmetic collectors.
- Social leaderboard players.

Not optimizing for:
- Hardcore real-time competitive esports.
- Gambling-style monetization.
- Heavy narrative RPG complexity.

## Full release scope

In scope:
- Main journey with multiple worlds.
- Core match-3 board and all BUX2 tile mechanics.
- Specials, blockers, objectives and boosters.
- Same-board friend challenge.
- Daily Puzzle.
- Weekly League.
- Bear companion beside board.
- Bear map movement.
- Wardrobe cosmetics.
- Bear Village meta-progression.
- Economy, rewards, chests and streaks.
- Analytics, balancing and QA instrumentation.
- Backend support for profiles, challenges, leaderboards and events.

Out of scope for first complete release:
- Real-time multiplayer.
- Guild wars.
- User-generated levels.
- Trading cosmetics between users.
- Fully procedural level generation.
- Cosmetics that alter gameplay.

## Primary user flows

1. New player onboarding:
   - install → level 1 → learn match → complete level → see Bear reaction → collect reward → advance map.

2. Main progression:
   - open app → choose next level → play → earn stars/coins → upgrade Bear Village → unlock cosmetics/worlds.

3. Friend challenge:
   - complete level → send challenge → friend plays same board → compare score/time/moves → claim reward/rematch.

4. Daily retention:
   - claim daily reward → play Daily Puzzle → check league/challenges → continue journey.

5. Personalization:
   - earn cosmetic shards/tokens → open wardrobe → equip bear outfit → appear in map/challenge leaderboard.

## Success criteria

- Players understand core match-3 and first blocker within first session.
- Same-board challenge is easy to send and accept.
- Challenge results feel fair and explain why someone won.
- Bear companion improves emotional connection without distracting from board.
- Economy gives reasons to play without making levels feel unfair.
- All shipped levels pass QA thresholds.
- App is stable, performant and app-store ready.

## Release criteria

- All release-blocker QA gates pass.
- Deterministic challenge validation works.
- No known economy exploits.
- No known soft locks in level progression.
- Reduced motion and color/readability checks complete.
- Privacy, analytics and store compliance reviewed.
