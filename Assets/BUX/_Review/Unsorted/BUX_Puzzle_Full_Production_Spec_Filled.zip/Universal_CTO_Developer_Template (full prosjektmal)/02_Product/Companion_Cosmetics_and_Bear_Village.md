# Companion Character, Wardrobe and Bear Village Specification

## Companion concept

The Bear is the player's companion, mascot and avatar. The Bear appears:
1. beside the gameplay board,
2. on the level map,
3. in the wardrobe,
4. in friend challenge UI,
5. in Bear Village.

The Bear reacts to gameplay but does not alter gameplay unless represented by a separate Bear Head tile mechanic already handled by BoardEngine.

## Gameplay side companion

Reaction states:
- Idle
- SmallHappy
- BigCheer
- Surprised
- ComboCheer
- LowMovesWorried
- Victory
- Defeat
- HintPoint
- ChallengeWin
- ChallengeLose

Triggers:
- Match 3: SmallHappy, low priority.
- Match 4: Cheer.
- Match 5: BigCheer.
- Special created: Surprised + clap.
- Bomb explosion: Whoa reaction.
- Rainbow activation: BigCheer.
- Cascade x2: Clap.
- Cascade x3+: Jump.
- Objective completed: Happy dance.
- Moves <= 5: Worried.
- No move for 8 seconds: HintPoint.
- Level won: Victory.
- Level failed: Encourage.

Timing:
- Small: 0.5–0.8s.
- Medium: 0.8–1.2s.
- Big: 1.2–1.8s.
- Victory: 2.0–3.0s.

Rules:
- Reactions never block input.
- Reactions are queued with priority.
- Higher-priority reactions can replace lower-priority ones.
- Reduced motion mode uses expression swaps and small fades instead of jumps/shakes.

## Wardrobe

Categories:
- Headwear
- Body outfit
- Accessory
- Back item
- Expression
- Victory dance
- Map trail
- Profile frame
- Challenge emote

Rarity:
- Common
- Rare
- Epic
- Legendary
- Seasonal

Unlock sources:
- main levels
- daily streak
- friend challenge trophies
- weekly league
- seasonal events
- perfect clears
- Bear Village milestones

## Bear Village meta-progression

Purpose:
Give players a cozy non-board progression system that makes rewards meaningful.

Village locations:
- Berry Stand
- Honey Hut
- Mushroom House
- Bee Garden
- Picnic Area
- Flower Bridge
- Acorn Workshop
- Wardrobe Tent
- Challenge Board

Progression:
- Complete levels to earn stars.
- Spend stars on village upgrades.
- Upgrades unlock cosmetics, story beats, decorations and small non-power conveniences.
- Village does not provide unfair gameplay advantages in ranked challenge modes.

## Map companion

Map states:
- MapIdle
- MapWalkToNextLevel
- MapCelebrateWorldComplete
- MapOpenChest
- MapPointToEvent
- MapWaveAtPlayer
- MapSleepIfIdle

Flow:
1. Level completed.
2. Reward summary.
3. Map opens.
4. Bear walks from previous node to next node.
5. New node unlocks.
6. Bear idles at next node.

## Technical architecture

Components:
- CompanionController
- CompanionAnimator
- CompanionReactionQueue
- CompanionWardrobe
- CompanionCosmeticInventory
- MapCompanionController
- BearVillageController

Event flow:
BoardEngine resolves gameplay
→ BoardView emits presentation events
→ CompanionReactionQueue receives events
→ CompanionAnimator plays selected reaction

Companion does not mutate BoardEngine.
