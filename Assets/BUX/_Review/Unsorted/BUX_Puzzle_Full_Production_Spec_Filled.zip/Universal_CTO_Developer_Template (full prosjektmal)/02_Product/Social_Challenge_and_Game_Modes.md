# Social, Challenge and Competitive Modes

## Signature feature: Same-Board Challenge

Promise:
Challenge friends on the exact same board. Same seed. Same layout. Same objectives. The better player wins.

Challenge types:
1. Score Duel
   - Highest score wins.
2. Speed Duel
   - Fastest completion wins.
3. Efficiency Duel
   - Fewest moves used / most moves remaining wins.
4. Combo Duel
   - Biggest combo or highest cascade multiplier wins.
5. Daily Duel
   - Same board for all players for 24 hours.

Fair mode:
- Same levelId.
- Same boardSeed.
- Same tile spawn sequence.
- Same objective set.
- Same allowed boosters.
- Same scoring version.
- No paid power advantage.
- Cosmetics visible but no gameplay effect.

Casual mode:
- Boosters allowed.
- Fun/rematch-first mode.
- Not used for ranked league standings unless explicitly tagged.

## Challenge lifecycle

1. Player completes a level or daily challenge.
2. Game prompts: "Challenge a friend to beat your score?"
3. Player sends challenge.
4. Friend receives exact board seed and rules.
5. Friend plays.
6. Both players see score breakdown:
   - completion time
   - score
   - moves remaining
   - biggest combo
   - specials created
   - boosters used
   - no-booster bonus
7. Winner receives trophies/coins/challenge chest progress.
8. Loser receives small participation reward and rematch CTA.

## Anti-cheat and fairness

- Server validates score submissions for challenge/ranked modes.
- Client sends replay summary or move list when feasible.
- Score rules are versioned.
- Board seed and level config are immutable for a challenge once issued.
- If scoring version changes, old challenge remains on old version or expires.

## Leaderboards

Leaderboard types:
- Friends leaderboard.
- Daily puzzle leaderboard.
- Weekly league bracket of 30–50 players.
- Level-specific leaderboard.
- Event leaderboard.

Avoid making global leaderboard the main motivator. Friends and brackets are more emotionally reachable.

## Social cosmetics

Leaderboard rows should show:
- player name
- bear avatar
- outfit
- profile badge
- score/time
- challenge status

This makes cosmetic progression socially valuable without giving gameplay power.
