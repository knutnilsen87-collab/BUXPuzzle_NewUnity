# Progression, Difficulty and Retention Specification

## Product loop

Daily loop:
1. Open game.
2. Claim daily reward.
3. Play Daily Puzzle or continue main journey.
4. Earn stars, coins and cosmetic progress.
5. Upgrade/decorate Bear Village.
6. Challenge a friend on the same board.
7. Return later to claim challenge result and rematch.

Long-term loop:
- Unlock worlds.
- Master levels for 3 stars and Perfect Clear.
- Collect companion cosmetics.
- Build Bear Village.
- Climb weekly leagues.
- Return for seasonal events and new challenge boards.

## World structure

World 1: Berry Village
- Focus: basic matches, score, moves, collect red berries/blueberries.
- New: Red Berry, Blueberry, Green Leaf, Pink Flower.
- Background: level_background_berry_village.png.

World 2: Mossy Forest
- Focus: blockers and cleansing.
- New: Moss Patch, White Daisy, Mushroom.
- Background: level_background_calm_forest.png.

World 3: Picnic Path
- Focus: spatial objectives.
- New: Basket, Acorn.
- Goal: fill baskets and collect acorns.

World 4: Honey Hills
- Focus: multi-hit objectives and helpers.
- New: Honey Pot, Bee, Bear Head.
- Goal: collect honey, use helper reactions.

World 5: Magic Clearing
- Focus: super specials and support specials.
- New: Rainbow Blast Orb, Rainbow Flower, Covered Moss.
- Background: level_background_magic_clearing.png.

World 6: Champion Grove
- Focus: mastery, friend challenge, leaderboards, hard objectives.
- New: Super Berry, advanced special combinations.

## Difficulty model

Internal level difficulty score:

DifficultyScore =
- boardComplexity 0–2
- tileVariety 0–2
- blockerPressure 0–2
- objectivePressure 0–2
- moveLimitPressure 0–2
- specialDependency 0–2
- randomnessRisk 0–2

Difficulty bands:
- 1–2: Easy/tutorial.
- 3–4: Normal.
- 5–6: Hard.
- 7–8: Very Hard.
- 9–10: Expert/event/ranked only.

Cadence rule:
- Never place more than two hard levels back-to-back in the main path.
- After a very hard level, provide a satisfying reward or easier level.
- Every new mechanic gets: introduce → practice → combine → challenge.

## Full release content target

Recommended complete launch target:
- 120–180 main journey levels.
- 6 worlds.
- 1 Daily Puzzle mode.
- 1 Same-Board Friend Challenge mode.
- 1 Weekly League.
- 1 active seasonal event framework with first season content.
- 1 Bear Village meta-progression.
- Companion wardrobe with meaningful cosmetic unlocks.
- At least 3 boosters: Shovel, Pre-level Bomb, Pre-level Rocket.
- At least 25 cosmetics across rarity tiers.

This is not an prototype target; it is the minimum complete-game release target.
