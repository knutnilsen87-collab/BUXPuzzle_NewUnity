# User Personas

## Cozy Casual Player

Wants:
- relaxing levels
- cute art
- clear progression
- daily rewards
- low pressure

Risks:
- churns if levels become unfair
- dislikes aggressive monetization

## Social Challenger

Wants:
- beat friends
- fair board comparison
- fast rematches
- visible bragging rights

Risks:
- leaves if boosters make competition unfair
- loses trust if scores are unclear

## Collector/Decorator

Wants:
- outfits
- village upgrades
- limited event items
- profile badges

Risks:
- loses interest if rewards are only coins/boosters
- dislikes random drops with no progress path

## Completionist

Wants:
- 3 stars
- perfect clears
- leaderboards
- all cosmetics

Risks:
- frustrated by RNG-heavy levels
- needs clear mastery criteria
