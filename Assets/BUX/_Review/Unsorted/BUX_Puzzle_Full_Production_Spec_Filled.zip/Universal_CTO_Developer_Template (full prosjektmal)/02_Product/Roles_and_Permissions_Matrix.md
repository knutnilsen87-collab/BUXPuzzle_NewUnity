# Roles and Permissions Matrix

## Player

Can:
- play levels
- create/accept friend challenges
- equip cosmetics
- spend earned currencies
- participate in events/leagues

Cannot:
- edit level configs
- submit arbitrary challenge results
- grant own rewards

## Client

Can:
- run gameplay locally
- show presentation
- queue offline progress
- submit signed/validated results

Cannot:
- trust itself for ranked/fair leaderboard final authority
- alter server-owned economy balances

## Backend

Can:
- validate challenge config
- store profile/cloud save
- validate leaderboard submissions
- issue event config
- grant server-authoritative rewards

## Admin/LiveOps

Can:
- publish event configs
- adjust reward tables
- disable broken levels/events
- view analytics dashboards

Must not:
- change active challenge seed/rules after challenge creation
- alter economy without versioned change log
