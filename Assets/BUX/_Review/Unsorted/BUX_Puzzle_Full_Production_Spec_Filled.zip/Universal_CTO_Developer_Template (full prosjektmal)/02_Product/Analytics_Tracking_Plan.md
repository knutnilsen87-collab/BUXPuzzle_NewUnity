# Analytics Tracking Plan

## Goals

Analytics should answer:
- Do players understand each mechanic?
- Where do they fail or churn?
- Are levels fair?
- Are challenges driving returns?
- Are cosmetics meaningful?
- Is economy too generous or too restrictive?

## Core events

game_start
- app_version
- platform
- install_age_days

level_start
- level_id
- world_id
- attempt_number
- difficulty_band
- active_objectives
- tile_set
- allowed_boosters

level_end
- level_id
- result
- score
- stars
- moves_used
- moves_remaining
- duration_seconds
- boosters_used
- fail_reason
- cascades_count
- specials_created
- specials_activated

special_created
- special_type
- level_id
- move_index

special_activated
- special_type
- combo_type
- targets_cleared
- blockers_hit

objective_progress
- objective_type
- delta
- remaining

booster_used
- booster_type
- source
- level_id
- move_index

challenge_created
- challenge_id
- level_id
- mode
- seed_version
- booster_rule

challenge_completed
- challenge_id
- result
- score
- time
- moves_remaining
- friend_count_context

cosmetic_unlocked
- cosmetic_id
- category
- rarity
- source

cosmetic_equipped
- cosmetic_id
- category

village_upgrade
- building_id
- level
- cost_type

daily_reward_claimed
- streak_day
- reward_type

## Level health metrics

Per level:
- win rate
- average attempts to win
- fail with 1–2 moves remaining
- booster usage rate
- quit rate
- average score
- 3-star rate
- perfect clear rate

Targets:
- Early tutorial levels: high win rate.
- Normal levels: healthy challenge.
- Hard levels: meaningful retry without feeling impossible.
- Very hard levels: clearly labeled and rewarded.

## Privacy

Do not collect unnecessary personal data. Challenge friend relationships should use platform-safe IDs. Analytics should avoid collecting chat/contact content.
