# Full Tile Mechanics and Behavior Specification

This specification assumes the existing match-3 engine remains authoritative. The mechanics below should be implemented as engine rules only where already supported or deliberately added through isolated systems. Presentation, animation and companion reactions subscribe to resolved gameplay events.

## Tile taxonomy

| Asset | Category | Matchable | Primary purpose |
|---|---:|---:|---|
| red_berry_tile | Core match tile | Yes | Basic collect, tutorial, main identity |
| blueberry_tile | Core match tile | Yes | Cascade/combo feel |
| green_leaf_tile | Core match tile | Yes | Wind/line-special identity |
| pink_flower_tile | Core match tile | Yes | Bloom/support against moss |
| white_daisy_tile | Core match tile | Yes | Cleanse/precision against covered moss |
| mushroom_tile | Core match tile | Yes | Forest/magic personality, spore feedback |
| acorn_tile | Core/objective tile | Yes initially | Collect/drop objective |
| basket_tile | Objective object | No by default | Adjacent collection/fill |
| honey_pot_tile | Objective object | No by default | Multi-hit honey collection |
| bear_head_tile | Rare helper tile | Yes, rare | Signature helper and personality |
| bee_tile | Helper tile | Yes, controlled | Pollination/honey interaction |
| moss_patch_tile | Blocker | No | 1-hit blocker |
| covered_moss_tile | Blocker | No | 2-hit blocker |
| berry_bomb_tile | Special | Conditional | 3x3 burst |
| striped_berry_rocket_tile | Special | Conditional | Row/column clear |
| rainbow_blast_orb_tile | Super special | Conditional | Clear all of target type |
| rainbow_flower_tile | Support special | Conditional | Smart bloom/target cleanse |
| super_berry_booster_tile | High-power special | Conditional | Cross clear |
| shovel_booster_tile | Booster/HUD tool | No | Remove/damage/activate selected cell |

## Shared animation states

Every visible board element should support:
- normal
- selected
- hint
- falling
- landing
- resolve-highlight
- clearing
- disabled/input-locked
- objective-relevant
- reduced-motion equivalent

Animations must never be required for gameplay correctness. If animations are skipped, sped up or reduced, BoardEngine state must still resolve identically.

## Red Berry

Role: main basic collect tile.

Mechanic:
- Match 3 clears matched red berries.
- Match 4 creates Striped Berry Rocket using the existing special creation rule.
- Match 5 straight creates Rainbow Blast Orb.
- T/L or 5-cluster can create Berry Bomb if the engine supports shape detection.
- Counts toward red berry collection objectives.

Behavior:
- Used from level 1.
- Good for score tutorials and collect goals.
- Should appear in most early and medium levels.

Animation and feedback:
- Idle: subtle juicy pulse.
- Selected: scale 1.08 and soft highlight ring.
- Match: squash/stretch, red sparkle/juice pop, shrink/fade.
- Objective collect: small red berry particle flies to goal_panel.
- By bomb/rainbow: faster pop with wave delay.

Required variations:
- red_berry_normal
- red_berry_selected_overlay
- red_berry_hint_glow
- red_berry_match_pop_fx
- red_berry_clearing_fx
- red_berry_objective_particle
- red_berry_locked_overlay

Edge cases:
- If under ice/cover in future, first clear cover layer.
- If removed during cascade, resolve through same scoring pipeline.
- If used in same-board challenge, scoring must be deterministic.

## Blueberry

Role: cascade/combo tile.

Mechanic:
- Match 3 clears normally.
- During cascade step 2+, Blueberry may show combo feedback.
- Optional score bonus must be deterministic and capped.

Recommended rule:
- Visual cascade bonus in full release launch.
- Score bonus only if scoring model is thoroughly validated.

Behavior:
- Feels bouncy and responsive.
- Good in boards with gravity/cascade potential.

Animation:
- Idle: tiny vertical bob.
- Falling: small rotation or bounce.
- Landing: more squash/stretch than other tiles.
- Match: blue pop ring.
- Cascade: blue glow ring and combo sparkle.

Variations:
- blueberry_normal
- blueberry_selected_overlay
- blueberry_hint_glow
- blueberry_landing_bounce_fx
- blueberry_match_pop_fx
- blueberry_cascade_glow
- blueberry_clearing_fx

Edge cases:
- Shovel removal does not trigger cascade bonus.
- Cascade bonus feedback only when ResolveTrace.cascadeIndex >= 2.
- Do not stack multiple combo popups on the same cell.

## Green Leaf

Role: wind/line-special identity.

Mechanic:
- Match 3 clears normally.
- Match 4 creates line special: Striped Berry Rocket or Wind Line.
- Line activation clears row or column depending on orientation.

Behavior:
- Teaches row/column clearing.
- Direction must be obvious.

Animation:
- Idle: small rotation.
- Falling: slight spin, settles on landing.
- Match: wind swirl and dissolve.
- Special creation: leaf spin + stripe/direction marker.
- Activation: gust travels across row/column and clears in wave.

Variations:
- green_leaf_normal
- green_leaf_selected_overlay
- green_leaf_hint_glow
- green_leaf_wind_swirl_fx
- green_leaf_line_horizontal
- green_leaf_line_vertical
- green_leaf_clearing_fx

Edge cases:
- Reduced motion replaces spin with glow/flash.
- Direction indicator must remain visible in colorblind/reduced contrast scenarios.

## Pink Flower

Role: bloom/support tile against moss.

Mechanic:
- Match 3 clears normally.
- If matched adjacent to moss_patch_tile, applies one moss hit.
- If no blocker nearby, behaves as normal collect tile.

Behavior:
- Introduces positive “nature clears nature” logic.
- Good in moss tutorial levels.

Animation:
- Idle: petals subtly open/close.
- Selected: petals brighten.
- Match: bloom ring expands from match group center.
- Against moss: pollen particles and moss damage feedback.

Variations:
- pink_flower_normal
- pink_flower_selected_overlay
- pink_flower_hint_glow
- pink_flower_bloom_open
- pink_flower_bloom_pulse_fx
- pink_flower_pollen_fx
- pink_flower_clearing_fx

Edge cases:
- Same moss cell should receive only intended hits per resolve step.
- Bloom cannot affect inactive cells.
- If extra blocker damage creates balance issues, make it visual-only and keep normal adjacent-hit rules.

## White Daisy

Role: cleanse/precision tile.

Mechanic:
- Match 3 clears normally.
- If matched adjacent to covered_moss_tile, weakens or removes one cover layer.
- More precise than Pink Flower; it targets covered/dirty blockers rather than broad bloom.

Behavior:
- Introduced after Moss Patch.
- Teaches layered blockers.

Animation:
- Idle: soft white shimmer.
- Match: clean flash and petal burst.
- Cleanse: white sparkle travels to covered moss.

Variations:
- white_daisy_normal
- white_daisy_selected_overlay
- white_daisy_hint_glow
- white_daisy_cleanse_flash_fx
- white_daisy_petal_burst_fx
- white_daisy_clearing_fx

Edge cases:
- Does not damage ordinary tiles.
- If no covered moss nearby, normal clear only.
- In same-board challenge, target selection must be deterministic.

## Mushroom

Role: magical forest personality tile.

Mechanic:
- Match 3 clears normally.
- Optional: matched Mushroom sends a visual spore puff.
- Later event mechanic: spore puff can weaken moss in event levels only.

Behavior:
- Adds distinct shape/color and magic-clearing atmosphere.
- Useful for collection objectives.

Animation:
- Idle: cap bounce.
- Match: compress, spore puff, fade.
- Landing: rubbery bounce.

Variations:
- mushroom_normal
- mushroom_selected_overlay
- mushroom_hint_glow
- mushroom_spore_puff_fx
- mushroom_match_bounce_fx
- mushroom_clearing_fx
- mushroom_objective_particle

Edge cases:
- Spore must not obscure board readability.
- Avoid adding random spread/growth in main path unless carefully balanced.

## Acorn

Role: collect/drop tile.

Mechanic launch version:
- Match 3 clears normally.
- Counts toward acorn collect objectives.

Advanced levels:
- Acorn can become a drop objective: move/fall acorns to bottom collection cells.

Behavior:
- Feels heavier than berries.
- Strong fit for Bear Village resource fantasy.

Animation:
- Idle: minimal motion.
- Landing: heavier thud/dust.
- Match: shell crack/pop.
- Drop collect: acorn falls into basket/HUD.

Variations:
- acorn_normal
- acorn_selected_overlay
- acorn_hint_glow
- acorn_crack_fx
- acorn_shell_particles
- acorn_heavy_landing_fx
- acorn_objective_particle

Edge cases:
- Drop objective requires deterministic gravity.
- If acorn is special-targeted by Rainbow, it clears as normal target type unless protected by objective mode.

## Basket

Role: objective object.

Mechanic:
- Not matchable by default.
- Collects adjacent matched fruit/nature tiles.
- Fill stages: empty → fill_01 → fill_02 → full.
- Objective completes when required baskets are full or total basket progress is met.

Behavior:
- Creates spatial objective: match near basket.
- Gives level goals beyond simple collection.

Animation:
- Adjacent collect: matched tile particle flies into basket.
- Fill stage: basket visibly fills.
- Complete: sparkle, small bounce, objective tick.

Variations:
- basket_empty
- basket_fill_01
- basket_fill_02
- basket_full
- basket_collect_particle_fx
- basket_complete_sparkle_fx

Edge cases:
- Basket should not fall unless explicitly designed.
- Basket cannot be selected/swapped.
- Specials may feed basket if they clear adjacent objective-relevant tiles; define this per level.

## Honey Pot

Role: multi-hit objective object.

Mechanic:
- Not matchable by default.
- Requires two adjacent hits:
  - Hit 1: lid cracks.
  - Hit 2: pot opens and honey is collected.
- Shovel applies one hit.
- Bee and Bear may prioritize Honey Pot.

Behavior:
- Central identity object for Bear/Bee/Honey worlds.
- Great for mid-game.

Animation:
- Idle: honey glisten.
- Hit 1: lid wobble/crack.
- Hit 2: honey drip/open.
- Collected: honey particle flies to goal panel; Bear reacts happily.

Variations:
- honey_pot_full
- honey_pot_cracked
- honey_pot_open
- honey_pot_collected
- honey_drip_fx
- honey_collect_particle_fx

Edge cases:
- Multiple adjacent matches in same resolve can either count once or multiple times; recommended: once per resolve step for readability.
- Bomb/rocket hit counts as one hit unless special rules state otherwise.

## Bear Head

Role: rare signature helper tile.

Mechanic:
- Match 3 Bear clears bears.
- After match, Bear Paw targets one useful cell.
- Target priority:
  1. Honey Pot objective
  2. Basket objective
  3. Covered Moss
  4. Moss Patch
  5. Random blocker using deterministic seed
  6. Score bonus if no target exists

Behavior:
- Rare spawn; used for personality and helpful moments.
- Should not make levels solve themselves.

Animation:
- Idle: blink/breathing/ear twitch.
- Selected: happy bounce.
- Match: bear hops and smiles.
- Paw: target highlight, paw swipe, impact.

Variations:
- bear_normal
- bear_blink_01
- bear_blink_02
- bear_happy
- bear_hint_wave
- bear_match_jump
- bear_paw_swipe_fx
- bear_paw_impact_fx
- bear_success_fx

Edge cases:
- Multiple Bear matches queue paw effects; do not overlap.
- Paw cannot target inactive cells.
- All target choice must be deterministic for challenges.

## Bee

Role: helper/pollination tile.

Mechanic:
- Match 3 Bee clears bees.
- Bee flies to nearest useful Honey Pot or Flower target.
- Priority:
  1. Honey Pot needing hit
  2. Covered Moss adjacent to Daisy/Flower context
  3. Basket needing adjacent collect
  4. Score sparkle if no target

Behavior:
- Appears mainly in Honey/Bloom worlds.
- Adds movement and life.

Animation:
- Idle: wing flutter/hover.
- Selected: wiggle.
- Match: bee flies upward, then to target with trail.
- Target impact: pollination sparkle or honey hit.

Variations:
- bee_normal
- bee_wings_01
- bee_wings_02
- bee_selected_overlay
- bee_flight_trail_fx
- bee_pollinate_fx
- bee_honey_hit_fx
- bee_clearing_fx

Edge cases:
- Bee target must be deterministic.
- If target disappears before bee reaches it, retarget once or convert to score sparkle.
- Avoid long flight time during rapid cascades.

## Moss Patch

Role: 1-hit blocker.

Mechanic:
- Not matchable.
- Removed by adjacent match or special hit.
- Blocks cell until cleared.

Behavior:
- First blocker tutorial.
- Flower/Daisy interactions should visually feel especially effective.

Animation:
- Hit: shake and small leaf/dust particles.
- Remove: dissolve/reveal cell.

Variations:
- moss_patch_full
- moss_patch_hit_fx
- moss_patch_removed_fx
- moss_leaf_particles_fx

Edge cases:
- Does not fall unless designed.
- If on top of a tile layer in future, clarify whether tile beneath is revealed.

## Covered Moss

Role: 2-hit blocker.

Mechanic:
- Not matchable.
- Hit 1 converts to Moss Patch.
- Hit 2 removes Moss Patch.
- Shovel removes one layer.

Behavior:
- Introduced after standard Moss.
- Used in later challenge and event levels.

Animation:
- Hit 1: cover cracks/peels.
- Transition: covered_moss → moss_patch.
- Hit 2: moss dissolves.
- Daisy hit: cleaner, brighter transition.

Variations:
- covered_moss_full
- covered_moss_cracked
- covered_moss_to_moss_transition_fx
- covered_moss_removed_fx
- covered_moss_cleanse_fx

Edge cases:
- Simultaneous hits should not skip unclear states visually; engine may resolve both but presentation should communicate layer removal clearly.
- Special hits count as defined by level rules; default one hit.

## Berry Bomb

Role: 3x3 burst special.

Mechanic:
- Created by T/L match or configured 5-cluster.
- Activated by swap, match inclusion, special hit or Shovel.
- Clears 3x3 valid area around bomb and damages blockers once.

Behavior:
- Strong but readable.
- Best against moss clusters and honey pots.

Animation:
- Idle: tiny fuse sparkle.
- Activation: scale-up anticipation, short pause, explosion center/ring, smoke.
- Affected cells flash before clearing.

Variations:
- berry_bomb_normal
- berry_bomb_fuse_01
- berry_bomb_fuse_02
- berry_bomb_armed
- berry_bomb_explosion_center_fx
- berry_bomb_explosion_ring_fx
- berry_bomb_smoke_fx

Edge cases:
- Board edges only affect valid cells.
- Inactive/protected cells ignored.
- Bomb hit by another special activates instead of disappearing.

## Striped Berry Rocket

Role: line clear special.

Mechanic:
- Created by Match 4.
- Orientation depends on swipe/match direction.
- Activation clears entire row or column.

Behavior:
- Direction must be visually obvious.
- Combos with Bomb/Rainbow in advanced rules.

Animation:
- Idle: tiny wiggle.
- Selected: stripe glows.
- Activation: rocket fires along row/column with trail; cells clear in wave.

Variations:
- striped_berry_rocket_horizontal
- striped_berry_rocket_vertical
- striped_berry_rocket_selected
- striped_berry_rocket_charge_fx
- rocket_trail_horizontal_fx
- rocket_trail_vertical_fx
- rocket_impact_fx

Edge cases:
- If orientation unknown, infer from match direction; fallback deterministic.
- Rocket + Rocket can clear row + column.
- Rocket cannot clear inactive cells.

## Rainbow Blast Orb

Role: color-clear super special.

Mechanic:
- Created by straight Match 5.
- Swap with normal tile to clear all tiles of that tile type.
- Does not consume if invalid target is selected.

Behavior:
- Rare high-payoff moment.
- Excellent for objectives and social high scores.

Animation:
- Idle: rainbow shimmer/pulse.
- Selected: board dims lightly, valid target glows.
- Activation: target type highlight, beams to all targets, wave clear.

Variations:
- rainbow_blast_orb_normal
- rainbow_blast_orb_shimmer_fx
- rainbow_blast_orb_selected_glow
- rainbow_blast_orb_charge_fx
- rainbow_blast_orb_beam_fx
- rainbow_blast_orb_hit_fx
- rainbow_blast_orb_wave_clear_fx

Edge cases:
- Cannot target blockers unless they have tile layer.
- Does not target inactive cells.
- Rainbow + Rainbow full-board clear reserved for advanced content.

## Rainbow Flower

Role: smart support special.

Mechanic:
- Activation sends bloom pulses to 5 useful targets.
- Target priority:
  1. Honey Pot needing hit
  2. Covered Moss
  3. Moss Patch
  4. Basket needing collect
  5. Objective-relevant tile cluster
- It should not simply duplicate Rainbow Orb.

Behavior:
- More strategic and gentle than Bomb.
- Strong in magic-clearing worlds.

Animation:
- Idle: multicolor petal shimmer.
- Activation: flower opens, pulses travel to targets, targets sparkle/cleanse.

Variations:
- rainbow_flower_normal
- rainbow_flower_selected
- rainbow_flower_bloom_charge_fx
- rainbow_flower_petals_open_fx
- rainbow_flower_target_beam_fx
- rainbow_flower_cleanse_impact_fx

Edge cases:
- Target selection deterministic.
- If fewer than 5 useful targets exist, use fewer pulses, then score sparkle.
- Do not over-clear the board.

## Super Berry Booster

Role: high-power special.

Mechanic:
- Clears a cross pattern: full row + full column from its cell.
- Damages blockers in the cross.
- Created by advanced match shape or awarded in events.

Behavior:
- Distinct from Bomb radius and Rocket line.
- Strong late-game payoff.

Animation:
- Idle: energetic glow.
- Activation: charge, horizontal and vertical beams, center burst.

Variations:
- super_berry_normal
- super_berry_selected
- super_berry_charge_fx
- super_berry_cross_beam_horizontal_fx
- super_berry_cross_beam_vertical_fx
- super_berry_center_burst_fx

Edge cases:
- Does not affect inactive cells.
- Cross pattern should be visually previewed before clear.
- Can be disabled in fair friend challenge if not present in seed.

## Shovel Booster

Role: HUD booster/tool.

Mechanic:
- Player selects Shovel from inventory.
- Board enters targeting mode.
- Tap valid cell:
  - normal tile: remove
  - Moss: damage/remove one layer
  - Covered Moss: remove one layer
  - Honey Pot: one hit
  - Bomb/Rocket/Special: activate special
- Does not consume move by default.
- Consumes one Shovel.

Behavior:
- Rescue tool, not normal tile.
- Should be unavailable in ranked/fair no-booster challenges.

Animation:
- HUD selected: button scale, board dim, valid cells highlight.
- Use: shovel swings, impact particles, target reacts.

Variations:
- shovel_icon_normal
- shovel_icon_selected
- shovel_icon_disabled
- shovel_cursor
- shovel_target_highlight_fx
- shovel_swing_01
- shovel_swing_02
- shovel_impact_fx
- shovel_dirt_particles_fx

Edge cases:
- Cannot use during resolve/cascade.
- Cannot use after level complete/fail.
- Cannot use on inactive cells.
- If used on Rainbow, require target type or reject with clear feedback.

## Special combinations

Launch recommended:
- Bomb + Bomb: 5x5 explosion.
- Rocket + Rocket: row + column clear.
- Rocket + Bomb: three-row/three-column blast depending orientation.
- Rainbow + normal tile: clear target type.
- Shovel + special: activate special.

Advanced/post-launch-ready but can ship if stable:
- Rainbow + Bomb: convert target-type tiles to bombs, then detonate.
- Rainbow + Rocket: convert target-type tiles to rockets.
- Rainbow + Rainbow: clear all clearable tiles, protected blockers excluded.
- Rainbow Flower + Bomb: bloom pulses + 3x3 burst at target priorities.

## Determinism requirement for social challenges

All random-like selections must use challenge seed:
- tile spawn
- helper target selection
- cascade generation
- Bear Paw target
- Bee target
- Rainbow Flower target
- possible shuffle

No client-local non-deterministic random calls are allowed inside fair challenge resolution.
