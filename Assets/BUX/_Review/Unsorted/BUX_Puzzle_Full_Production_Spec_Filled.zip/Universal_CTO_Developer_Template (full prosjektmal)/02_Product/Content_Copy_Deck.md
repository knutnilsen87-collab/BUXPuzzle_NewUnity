# Content and Copy Deck

## Tone

Warm, cozy, encouraging, playful. No harsh failure language.

## Core copy examples

Level complete:
- "Sweet! You cleared the path."
- "Berry good move!"
- "The forest is opening up."

Fail:
- "So close! Try one more clever move."
- "Almost there — the Bear believes in you."

Challenge prompt:
- "Think a friend can beat your score?"
- "Same board. Same rules. Best player wins."

Challenge win:
- "You won this round!"
- "Your Bear is doing a victory dance."

Challenge loss:
- "They beat your score — rematch?"
- "Same board, new chance."

Low moves:
- "Only a few moves left. Make them count."

Wardrobe:
- "Dress your Bear."
- "New outfit unlocked!"
- "Try this look on the map."

Daily:
- "Today's forest puzzle is ready."
- "Come back tomorrow for your next reward."
