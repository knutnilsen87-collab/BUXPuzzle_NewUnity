# Project Cloning Instructions

This package is a planning/specification package, not the actual game repo.

To apply:
1. Copy relevant docs into the game repo `/docs`.
2. Create branch `full-release-planning`.
3. Audit current engine against `Technical_Architecture_Spec.md`.
4. Convert docs into implementation tickets.
5. Do not overwrite existing working game code without review.
