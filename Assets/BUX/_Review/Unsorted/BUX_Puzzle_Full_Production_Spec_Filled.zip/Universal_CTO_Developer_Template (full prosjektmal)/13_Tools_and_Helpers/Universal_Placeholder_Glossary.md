# Glossary

BoardEngine:
Authoritative gameplay logic.

ResolveTrace:
Structured record of what happened after a move.

Same-Board Challenge:
Mode where two players compete on exact same seed/config.

Bear Companion:
Cosmetic/personality character beside board and on map.

Bear Head Tile:
Separate rare helper tile inside board gameplay.

Bear Village:
Meta-progression/decorative village hub.

Fair Mode:
Challenge mode with no unequal booster advantage.

Casual Mode:
Challenge mode where boosters may be allowed and results are not ranked as fair.
