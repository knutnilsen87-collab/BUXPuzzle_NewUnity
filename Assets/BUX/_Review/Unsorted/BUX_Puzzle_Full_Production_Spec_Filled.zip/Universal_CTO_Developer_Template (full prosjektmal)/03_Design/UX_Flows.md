# UX Flows

## Level start flow

Map node tap → Level preview → Objective explanation → optional boosters → Start → Board loads → Bear idle.

## Gameplay flow

Player swaps tile → BoardEngine validates → animation → match resolve → objectives/scoring → cascade → companion reaction → next input unlocked.

## Level complete flow

Final objective met → completion animation → score/stars → rewards → challenge prompt → map → Bear walks.

## Level fail flow

Moves exhausted → fail summary → optional extra moves → retry/map → no harsh language.

## Challenge flow

Complete level → challenge CTA → select friend/share → challenge sent → pending state → result notification → comparison → rematch.

## Wardrobe flow

Reward unlock → wardrobe prompt → preview item → equip → Bear updates across map/gameplay/social.

## Bear Village flow

Earn stars → enter village → upgrade building → unlock cosmetic/story/decor → Bear celebrates.
