# UI Specification

## Main gameplay screen

Required elements:
- board centered
- moves_left_panel visible
- score_panel visible
- goal_panel visible
- pause/menu button
- booster tray
- companion Bear beside board
- level objective summary before start

Mobile layout:
- Board remains primary visual focus.
- Companion appears to side or below depending aspect ratio.
- UI panels must not cover board cells.
- Booster tray must be reachable by thumb.

## Level map

Required elements:
- world path
- level nodes
- Bear companion walking/idle
- event entry
- daily puzzle entry
- challenge inbox
- reward chest progress
- Bear Village entry

## Wardrobe

Required elements:
- Bear preview
- category tabs
- item grid
- locked/unlocked states
- source label for locked items
- equip button
- rarity indicator
- no power stats

## Challenge result screen

Required elements:
- player vs friend comparison
- bear avatars/outfits
- score
- time
- moves remaining
- combo bonus
- boosters used policy
- winner explanation
- rematch button

## Bear Village

Required elements:
- village scene
- buildings/decorations
- upgrade buttons
- star/coin costs
- unlock preview
- non-pay-to-win reassurance through copy where needed
