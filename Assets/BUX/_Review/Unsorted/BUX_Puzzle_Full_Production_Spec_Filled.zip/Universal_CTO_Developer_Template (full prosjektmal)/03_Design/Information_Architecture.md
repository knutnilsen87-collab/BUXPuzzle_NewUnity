# Information Architecture

## Top-level screens

- Splash / loading
- Home / map
- Level preview
- Gameplay board
- Level complete/fail
- Daily Puzzle
- Challenges
- Weekly League
- Bear Village
- Wardrobe
- Shop/rewards
- Settings

## Settings

- sound
- music
- haptics
- reduced motion
- color assistance
- notifications
- privacy
- account/cloud save
- support

## Navigation priorities

Home map must expose:
- next level
- daily puzzle
- pending challenge
- current event
- Bear Village reward opportunity

Avoid overwhelming the player with too many buttons before level 10.
