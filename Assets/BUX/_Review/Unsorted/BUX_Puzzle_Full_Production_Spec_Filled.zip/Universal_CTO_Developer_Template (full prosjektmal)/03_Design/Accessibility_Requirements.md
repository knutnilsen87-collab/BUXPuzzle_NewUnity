# Accessibility Requirements

## Visual

- Tile types must have unique silhouettes.
- Do not rely on color alone.
- Specials need clear icons/directions.
- Text contrast must be readable over backgrounds.
- Objective counts must be large enough on small screens.

## Motion

- Reduced motion setting required.
- Disable heavy shake/spin in reduced motion.
- Replace large effects with glow/fade.
- Companion jumps replaced with expression swaps.

## Input

- Board cells and buttons must have comfortable touch targets.
- Booster selection requires clear confirm/cancel.
- Invalid actions must provide gentle feedback.

## Cognitive load

- Introduce one mechanic at a time.
- Keep tutorial text short.
- Provide level objective preview.
- Avoid simultaneous popups during cascade.

## Audio/haptics

- Audio cues should reinforce but not be required.
- Haptics should be optional.
