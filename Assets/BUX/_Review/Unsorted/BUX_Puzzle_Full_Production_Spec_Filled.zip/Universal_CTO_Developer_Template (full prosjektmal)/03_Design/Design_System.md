# Design System

## Visual direction

Cozy forest premium:
- warm wood surfaces
- soft berry colors
- readable tile silhouettes
- gentle depth
- playful but not childish
- polished animation states

## Design principles

- Board readability beats decoration.
- One primary action per screen.
- Effects should feel juicy but never obscure tile state.
- Companion is expressive but secondary during board play.
- Cosmetics should be visible in social contexts.

## Core surfaces

- Wooden board frame.
- Brown board cells.
- Soft vignette behind modals.
- Rounded panels for goals, moves and score.
- Cozy backgrounds per world.

## Tile visual rules

- Every core tile needs unique silhouette, not only color.
- Specials need stronger glow/energy and clear state.
- Blockers need clear HP/layer readability.
- Objective objects must not look swappable if they are not swappable.

## Motion rules

- Small feedback: 0.1–0.3s.
- Resolve sequence should feel fast and readable.
- Major special payoff: 0.5–0.9s before cascade continues.
- Companion reactions do not block board input.
- Reduced motion removes spin, excessive bounce and shake.

## Rarity/cosmetic style

Common:
- simple hats/scarves.

Rare:
- themed accessories.

Epic:
- animated details, trails, dances.

Legendary:
- seasonal hero outfits, unique profile pose.
