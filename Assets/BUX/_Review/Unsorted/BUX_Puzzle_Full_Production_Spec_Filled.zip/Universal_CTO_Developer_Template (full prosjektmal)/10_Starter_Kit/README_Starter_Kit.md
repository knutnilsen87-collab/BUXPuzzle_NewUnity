# Starter Kit README

This starter kit should be adapted to the existing game repo. It is not a replacement for the repo.

Use the docs in this package as implementation source of truth. The repo skeleton is generic and should be merged carefully with the actual Unity/mobile game structure.
