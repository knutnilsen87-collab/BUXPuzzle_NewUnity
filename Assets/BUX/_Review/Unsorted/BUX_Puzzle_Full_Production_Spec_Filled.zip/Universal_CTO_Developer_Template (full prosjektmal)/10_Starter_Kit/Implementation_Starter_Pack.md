# Implementation Starter Pack

## Start here for developers

1. Audit existing engine.
2. Verify BoardEngine/presentation separation.
3. Add deterministic seed test.
4. Add TileCatalog and visual profile system.
5. Implement BUX2 tile taxonomy.
6. Build first world levels.
7. Add companion reaction events.
8. Add challenge seed model.

## First engineering tasks

- Create `Game.Core` tests.
- Create `TileVisualId`.
- Create `TileMechanicId`.
- Create `ObjectiveType`.
- Create `SpecialType`.
- Create `BlockerType`.
- Create `ChallengeSeed`.
- Create `ScoringRulesVersion`.
- Create `RewardService`.

## Do not do first

- Do not build monetization before economy fairness.
- Do not add random helper targeting without deterministic seed.
- Do not let animations change board state.
- Do not create cosmetics with gameplay power.
