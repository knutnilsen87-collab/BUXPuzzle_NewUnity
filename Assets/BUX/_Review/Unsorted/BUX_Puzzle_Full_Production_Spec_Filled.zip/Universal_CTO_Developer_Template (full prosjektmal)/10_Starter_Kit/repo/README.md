# BUX Puzzle Repo Starter

This repo skeleton is a placeholder for the actual game repository.

Recommended modules:
- Game.Core
- Game.Presentation
- Game.Progression
- Game.Economy
- Game.Social
- Game.LiveOps
- Game.BackendClient
- Game.Tests

Do not move authoritative board logic into presentation scripts.
