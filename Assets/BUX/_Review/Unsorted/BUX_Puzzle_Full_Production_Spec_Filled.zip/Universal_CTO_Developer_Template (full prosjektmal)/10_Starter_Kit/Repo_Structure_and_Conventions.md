# Repo Structure and Conventions

Recommended Unity structure:

Assets/Game/Core
Assets/Game/Core/Tests
Assets/Game/Presentation
Assets/Game/Presentation/Tiles
Assets/Game/Presentation/Companion
Assets/Game/Presentation/UI
Assets/Game/Configs/Levels
Assets/Game/Configs/Tiles
Assets/Game/Configs/Rewards
Assets/Game/Configs/Cosmetics
Assets/Game/Meta
Assets/Game/Social
Assets/Game/Economy
Assets/Game/LiveOps
Assets/Game/Art/BUX2
Assets/Game/Audio
Assets/Game/Scenes

Naming:
- Tile assets: snake_case original asset names allowed.
- Script classes: PascalCase.
- Configs: `World_01_BerryVillage`, `Level_001`, etc.
- Versions: `scoring_v1`, `tile_rules_v1`.
