# Endpoint Permissions Matrix

| Endpoint | Auth | Notes |
|---|---|---|
| POST /profile/create | optional/device auth | Creates player |
| GET /profile/{id} | user auth | Own profile only unless public summary |
| POST /save/sync | user auth | Validate deltas |
| POST /challenge/create | user auth | Creates challenge |
| GET /challenge/{id} | challenge participant/share token | Limited data |
| POST /challenge/{id}/submit | participant auth | Validate |
| GET /leaderboard/{type} | user auth/public depending type | No private data |
| GET /events/current | app auth | Public config |
| POST /purchase/validate | user auth | Server validation |
