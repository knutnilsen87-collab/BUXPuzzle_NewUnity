# Privacy and Data Handling

## Data collected

- user ID
- display name
- progress
- inventory/cosmetics
- challenge results
- gameplay analytics
- device/app metadata for debugging

## Sensitive data

Avoid collecting:
- real names unless platform provides them with consent
- contact lists
- precise location
- message contents

## Player controls

- privacy policy accessible from settings
- notification opt-in/out
- account deletion path
- data export/deletion if required by market regulations
