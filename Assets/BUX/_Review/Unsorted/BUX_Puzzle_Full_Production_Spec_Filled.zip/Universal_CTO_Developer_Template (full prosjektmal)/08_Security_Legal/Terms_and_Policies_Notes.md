# Terms and Policies Notes

Terms should cover:
- acceptable use
- challenge/leaderboard fairness
- cheating and score removal
- virtual items/cosmetics
- purchases/refunds per platform
- account deletion
- event changes and expirations

Privacy policy should cover:
- analytics
- challenge data
- cloud save
- purchase validation
- notifications
