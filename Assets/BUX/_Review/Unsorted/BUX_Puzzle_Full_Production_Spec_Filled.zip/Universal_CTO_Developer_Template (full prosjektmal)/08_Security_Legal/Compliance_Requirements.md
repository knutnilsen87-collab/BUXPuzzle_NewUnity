# Compliance Requirements

## App store

- Clear purchase disclosures.
- Privacy labels accurate.
- No misleading loot box/gambling presentation.
- Push notifications require consent.
- Child-directed compliance reviewed if targeting children.

## Ads/IAP

If ads or IAP are used:
- disclose clearly
- avoid dark patterns
- protect fair challenge integrity
- validate purchases server-side
