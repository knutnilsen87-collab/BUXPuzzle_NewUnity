# Security Requirements

## Client trust

The client is not fully trusted for:
- purchases
- ranked challenge score
- leaderboard rank
- high-value economy grants

## Challenge security

- Challenge config stored server-side.
- Results include scoring version.
- Replay/move summary validation where feasible.
- Suspicious scores flagged.

## Economy security

- Centralized RewardService.
- Transaction log.
- Receipt validation server-side for IAP.
- No client-only premium currency grants.

## Data protection

- Do not collect unnecessary personal data.
- Avoid storing contact book data.
- Use platform friend/share mechanisms safely.
