# Dependency Map

## Hard dependencies

Social Challenge depends on:
- deterministic BoardEngine
- versioned LevelConfig
- versioned ScoringRules
- backend challenge storage

Companion reactions depend on:
- gameplay event stream
- presentation layer
- reaction priority queue

Wardrobe depends on:
- cosmetic catalog
- inventory
- Bear rendering layers

Bear Village depends on:
- stars/economy
- progression state
- map/home UI

Events depend on:
- event config
- reward tables
- analytics
- backend or remote config

## Critical path

Engine determinism → Level config → Tile mechanics → Level content → Challenge mode → QA/balance.
