# Implementation Phases

## Phase 1 — Foundation

- Audit existing engine.
- Add tests around swaps, matches, cascades and specials.
- Establish config loading.
- Establish deterministic RNG.

## Phase 2 — Gameplay content

- Implement tile catalog.
- Implement blocker/objective catalog.
- Implement animation profile system.
- Build first 60 levels.

## Phase 3 — Meta and social

- Implement map, rewards, wardrobe and village.
- Implement friend challenge.
- Implement backend integrations.

## Phase 4 — Full content production

- Complete worlds and levels.
- Complete cosmetics.
- Complete events.
- Balance economy and level difficulty.

## Phase 5 — QA and launch

- Full regression.
- Device matrix.
- App store assets.
- Soft launch/testing if desired, but public release target remains full game.
