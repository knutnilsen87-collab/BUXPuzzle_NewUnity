# Backlog Epics and User Stories

## Epic: Core board

- As a player, I can swap adjacent tiles.
- As a player, invalid swaps revert clearly.
- As a player, matches clear with satisfying feedback.
- As a player, specials activate predictably.
- As a developer, BoardEngine is deterministic and testable.

## Epic: Tile mechanics

- As a player, I learn new tiles gradually.
- As a player, blockers have clear layer states.
- As a player, special combinations feel powerful and readable.

## Epic: Same-board challenge

- As a player, I can challenge a friend on the exact same board.
- As a player, I can see why I won or lost.
- As a player, I can rematch quickly.

## Epic: Companion

- As a player, my Bear reacts to my moves.
- As a player, I can dress my Bear.
- As a player, my Bear walks on the level map.

## Epic: Economy

- As a player, I earn coins, stars and cosmetics.
- As a player, I can spend rewards on useful/cosmetic items.
- As a player, I never feel forced to pay to compete fairly.

## Epic: Live content

- As a player, I get Daily Puzzle and weekly events.
- As a live team, we can configure events without app update.
