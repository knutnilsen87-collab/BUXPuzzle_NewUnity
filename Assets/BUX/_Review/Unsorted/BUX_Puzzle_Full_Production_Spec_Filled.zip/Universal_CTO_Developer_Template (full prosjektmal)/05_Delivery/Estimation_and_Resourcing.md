# Estimation and Resourcing

## Recommended team

- Game designer / level designer
- Unity gameplay engineer
- Unity UI/presentation engineer
- Backend engineer
- Artist/animator
- QA tester
- Product/analytics owner

## Highest-effort areas

1. Level design and balancing.
2. Board animation polish.
3. Deterministic challenge validation.
4. Companion/cosmetic rendering.
5. Economy tuning.
6. Device performance.

## Risk buffer

Allocate significant buffer for:
- special combo edge cases
- challenge determinism bugs
- economy exploits
- late-level balancing
- small-screen UI readability
