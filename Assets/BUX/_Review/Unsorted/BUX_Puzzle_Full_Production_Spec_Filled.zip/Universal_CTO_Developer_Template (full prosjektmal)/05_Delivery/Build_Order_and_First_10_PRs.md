# Build Order and First 10 PRs

## PR 1: Engine audit and test harness
- Add/verify tests for BoardEngine.
- Document current engine extension points.

## PR 2: Deterministic RNG and ResolveTrace contract
- Ensure challenge-compatible deterministic resolution.

## PR 3: Tile catalog and visual profile library
- Add TileVisualId, TileAnimationProfile, TileVisualProfileLibrary.

## PR 4: Core BUX2 tile implementation
- Red Berry, Blueberry, Leaf, Pink Flower, White Daisy, Mushroom, Acorn.

## PR 5: Blockers and objectives
- Moss Patch, Covered Moss, Basket, Honey Pot.

## PR 6: Specials and boosters
- Berry Bomb, Striped Rocket, Rainbow Orb, Rainbow Flower, Super Berry, Shovel.

## PR 7: Level config and first world
- Build Berry Village with tutorial progression.

## PR 8: Companion reaction system
- Board-side Bear reactions, reaction priority queue.

## PR 9: Map and Bear movement
- Level nodes, world path, Bear walk animation.

## PR 10: Rewards and economy foundation
- Wallet, reward grants, stars, coins, initial chests.
