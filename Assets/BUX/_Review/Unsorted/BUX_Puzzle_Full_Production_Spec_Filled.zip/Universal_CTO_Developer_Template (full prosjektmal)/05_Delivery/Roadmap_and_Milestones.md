# Roadmap and Milestones — Full Release

## Milestone 1: Engine verification and architecture hardening

- Confirm BoardEngine/presentation separation.
- Add deterministic seed tests.
- Validate ResolveTrace completeness.
- Confirm tile, blocker, objective and special extension points.

## Milestone 2: Complete tile system

- Implement all BUX2 tiles.
- Implement specials and blockers.
- Implement animation profiles.
- Add reduced motion.

## Milestone 3: Full level journey

- Build world map.
- Produce 120–180 launch levels.
- Implement difficulty scoring and QA.

## Milestone 4: Companion and cosmetics

- Board-side Bear reactions.
- Map movement.
- Wardrobe.
- Cosmetic inventory.
- Initial cosmetic catalog.

## Milestone 5: Economy and Bear Village

- Currencies.
- Reward tables.
- Chests.
- Bear Village buildings/upgrades.
- Daily reward.

## Milestone 6: Social challenge

- Same-board challenge seed.
- Friend challenge creation.
- Results comparison.
- Leaderboards.
- Anti-cheat validation.

## Milestone 7: Events and live readiness

- Daily Puzzle.
- Weekly League.
- First seasonal event.
- Event economy.

## Milestone 8: Release hardening

- QA pass.
- Device performance.
- Store compliance.
- Privacy review.
- Crash/analytics monitoring.
