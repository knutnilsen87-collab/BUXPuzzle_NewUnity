# Assumptions, Non-Goals and Constraints

## Assumptions

- Existing match-3 engine exists and can be reused.
- BoardEngine can or should be made deterministic.
- Game is built for iOS/Android.
- Unity/C# is likely, based on current engine naming patterns.
- BUX2 assets define the visual direction.
- First public release is full-featured, not prototype-first.

## Non-goals

- No real-money advantage in fair/ranked challenge modes.
- No gameplay power from cosmetics.
- No generic casino-like reward presentation.
- No massive world-building system that distracts from puzzle quality.
- No procedural levels as substitute for handcrafted level design at launch.

## Constraints

- The game must remain readable on small mobile screens.
- Every tile needs reduced-motion-friendly feedback.
- Social challenge requires deterministic seed and versioned scoring.
- Live events require backend/config discipline.
- Companion animations must not delay board resolve.
