# Success Metrics and KPIs

## Activation

- Tutorial completion rate.
- Level 1–10 completion rate.
- First special creation rate.
- First companion customization rate.
- First friend challenge sent.

## Retention

- Day 1 retention.
- Day 7 retention.
- Day 30 retention.
- Daily Puzzle participation.
- Friend challenge rematch rate.
- Bear Village upgrade rate.

## Engagement

- Levels played per session.
- Attempts per level.
- Daily challenge attempts.
- Friend challenges created/completed.
- Cosmetic items equipped.
- Village interactions per session.

## Gameplay health

- Level win rate by attempt.
- Booster usage rate by level.
- Fail rate with 1–2 moves remaining.
- Shuffle frequency.
- Average cascade count.
- Special creation and activation rates.

## Economy health

- Coin earn/spend ratio.
- Booster fragment conversion.
- Cosmetic unlock rate.
- Chest open rate.
- Event token earn/spend ratio.

## Social health

- Challenge send rate.
- Challenge acceptance rate.
- Rematch rate.
- Friend leaderboard view rate.
- Weekly league participation.

## Quality

- Crash-free sessions.
- ANR-free sessions.
- Average board resolve time.
- Asset load time.
- FPS during heavy special effects.
