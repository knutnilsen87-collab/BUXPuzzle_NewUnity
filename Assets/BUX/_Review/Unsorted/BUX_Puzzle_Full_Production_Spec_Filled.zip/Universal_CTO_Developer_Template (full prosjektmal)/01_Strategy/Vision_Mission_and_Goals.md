# Vision, Mission and Goals

## Vision

Create the coziest fair-competition match-3 game: a polished puzzle journey where players feel emotionally attached to their bear companion and keep returning to beat friends on identical boards.

## Mission

Deliver a complete mobile game with premium-feeling board interactions, charming forest identity, deterministic social challenge, and long-term cosmetic/meta progression.

## Product goals

- Make the first 10 levels immediately understandable and delightful.
- Make friend challenges feel fair, fast and rematchable.
- Make the Bear companion emotionally valuable without affecting competitive fairness.
- Make every new tile teach a clear gameplay concept.
- Make rewards useful without turning the economy into pay-to-win.
- Make content production scalable through config-driven levels, tiles and rewards.

## Full release goals

- Complete main journey.
- Daily challenge loop.
- Friend challenge loop.
- Bear Village meta loop.
- Cosmetic wardrobe.
- Events and weekly league.
- Analytics and balancing support.
- App store submission readiness.
