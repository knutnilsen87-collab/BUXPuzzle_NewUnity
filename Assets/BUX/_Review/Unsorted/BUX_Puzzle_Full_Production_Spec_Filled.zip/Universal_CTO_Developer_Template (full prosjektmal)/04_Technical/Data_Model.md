# Data Model

## Local save

- User progress.
- Completed levels and stars.
- Local inventory cache.
- Equipped cosmetics.
- Settings.
- Pending offline reward grants.
- Last known event configs.

## Server data

- Account/profile identity.
- Cloud save snapshot.
- Challenge records.
- Leaderboard submissions.
- Event progress where server-authoritative.
- Purchases/receipts if monetization exists.

## Config data

Store as versioned JSON/ScriptableObjects:
- TileCatalog
- LevelCatalog
- WorldCatalog
- ObjectiveCatalog
- RewardTables
- CosmeticCatalog
- EventCatalog
- ScoringRules
- ChallengeRules

## Versioning

Every challenge references:
- levelConfigVersion
- scoringVersion
- tileRuleVersion
- rewardVersion if reward attached
