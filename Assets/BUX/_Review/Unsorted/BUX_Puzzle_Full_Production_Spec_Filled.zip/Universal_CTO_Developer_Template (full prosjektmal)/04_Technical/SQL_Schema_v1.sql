-- BUX Puzzle Full Release schema sketch

CREATE TABLE users (
  user_id TEXT PRIMARY KEY,
  display_name TEXT,
  created_at TIMESTAMP NOT NULL,
  updated_at TIMESTAMP NOT NULL
);

CREATE TABLE challenges (
  challenge_id TEXT PRIMARY KEY,
  creator_user_id TEXT NOT NULL,
  level_id TEXT NOT NULL,
  board_seed TEXT NOT NULL,
  config_version TEXT NOT NULL,
  scoring_version TEXT NOT NULL,
  mode TEXT NOT NULL,
  booster_policy TEXT NOT NULL,
  expires_at TIMESTAMP NOT NULL,
  created_at TIMESTAMP NOT NULL
);

CREATE TABLE challenge_submissions (
  submission_id TEXT PRIMARY KEY,
  challenge_id TEXT NOT NULL,
  user_id TEXT NOT NULL,
  score INTEGER NOT NULL,
  duration_ms INTEGER,
  moves_remaining INTEGER,
  boosters_used_json TEXT,
  replay_summary_json TEXT,
  submitted_at TIMESTAMP NOT NULL
);

CREATE TABLE leaderboard_entries (
  leaderboard_id TEXT NOT NULL,
  user_id TEXT NOT NULL,
  score INTEGER NOT NULL,
  rank_score INTEGER NOT NULL,
  metadata_json TEXT,
  updated_at TIMESTAMP NOT NULL,
  PRIMARY KEY (leaderboard_id, user_id)
);

CREATE TABLE user_inventory (
  user_id TEXT NOT NULL,
  item_id TEXT NOT NULL,
  quantity INTEGER NOT NULL,
  updated_at TIMESTAMP NOT NULL,
  PRIMARY KEY (user_id, item_id)
);

CREATE TABLE user_cosmetics (
  user_id TEXT NOT NULL,
  cosmetic_id TEXT NOT NULL,
  unlocked_at TIMESTAMP NOT NULL,
  equipped BOOLEAN NOT NULL DEFAULT FALSE,
  PRIMARY KEY (user_id, cosmetic_id)
);
