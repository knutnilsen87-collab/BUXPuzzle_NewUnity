# Worker State Machine Spec

## Board resolve state machine

Idle
→ SwapRequested
→ SwapAccepted/SwapRejected
→ FindMatches
→ ResolveMatches
→ ActivateSpecials
→ DamageBlockers
→ UpdateObjectives
→ ApplyGravity
→ SpawnTiles
→ CascadeCheck
→ CompleteOrFailCheck
→ Idle

## Challenge submission worker

ReceivedSubmission
→ ValidateChallengeOpen
→ ValidateVersion
→ ValidateScoreOrReplay
→ StoreSubmission
→ RecalculateResults
→ GrantRewardsIfFinal
→ NotifyPlayers

## Event config worker

DraftConfig
→ ValidateConfig
→ Schedule
→ Active
→ Ended
→ RewardSettlement
→ Archived
