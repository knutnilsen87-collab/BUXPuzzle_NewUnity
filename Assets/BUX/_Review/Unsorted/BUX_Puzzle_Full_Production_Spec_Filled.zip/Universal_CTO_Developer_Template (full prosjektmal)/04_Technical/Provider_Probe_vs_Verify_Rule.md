# Provider Probe vs Verify Rule

Probe:
- Check whether service is available.
- Fetch event config.
- Fetch leaderboard.

Verify:
- Validate purchases.
- Validate ranked challenge submissions.
- Validate economy grants.

Never use client-only proof for purchases, ranked rewards or leaderboard finalization.
