# API Specification

## Required backend APIs

POST /profile/create
- creates or links player profile

GET /profile/{userId}
- retrieves profile/cloud save summary

POST /save/sync
- syncs progress and inventory deltas

POST /challenge/create
- creates deterministic same-board challenge

GET /challenge/{challengeId}
- retrieves challenge config

POST /challenge/{challengeId}/submit
- submits score/replay summary

GET /challenge/{challengeId}/results
- retrieves comparison results

GET /leaderboard/{type}
- friends/daily/weekly/event leaderboard

GET /events/current
- active events and daily puzzle config

POST /economy/grant
- server-authoritative grants only, restricted/internal

POST /purchase/validate
- validates app store purchase if IAP is used

## API principles

- Never trust client score blindly for ranked/fair challenge.
- Validate version and seed.
- Reject stale scoring versions where needed.
- Avoid sending unnecessary personal data.
