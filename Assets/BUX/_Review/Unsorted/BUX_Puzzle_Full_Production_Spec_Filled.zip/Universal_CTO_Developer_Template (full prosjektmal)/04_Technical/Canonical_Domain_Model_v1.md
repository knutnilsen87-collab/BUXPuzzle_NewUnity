# Canonical Domain Model

## Core entities

UserProfile:
- userId
- displayName
- levelProgress
- wallet
- inventory
- cosmetics
- equippedBearLook
- villageState
- settings

LevelConfig:
- levelId
- worldId
- boardShape
- tileSpawnTable
- objectives
- moveLimit
- blockers
- specials
- difficulty
- configVersion

BoardState:
- cells
- tiles
- blockers
- objectives
- score
- movesRemaining
- randomSeedState

ResolveTrace:
- moveIndex
- swap
- matches
- clears
- specialActivations
- blockerHits
- objectiveDeltas
- cascades
- scoreDeltas
- spawnedTiles

Challenge:
- challengeId
- creatorUserId
- targetUserId/shareCode
- levelId
- boardSeed
- configVersion
- scoringVersion
- mode
- boosterPolicy
- expiresAt
- submissions

CosmeticItem:
- cosmeticId
- category
- rarity
- unlockSource
- isEquipped

VillageBuilding:
- buildingId
- level
- upgradeCost
- rewardsUnlocked
