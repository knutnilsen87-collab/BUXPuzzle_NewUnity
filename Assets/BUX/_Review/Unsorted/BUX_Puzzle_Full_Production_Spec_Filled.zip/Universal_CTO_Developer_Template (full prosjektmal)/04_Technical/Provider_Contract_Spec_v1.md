# Provider Contract Spec

## External providers

- App Store / Google Play for purchases if used.
- Push notification provider.
- Analytics provider.
- Backend hosting/database provider.

## Contract rules

- Purchase validation server-side.
- Analytics must not collect unnecessary personal data.
- Push notifications opt-in and respectful.
- Backend APIs must version challenge/scoring configs.
