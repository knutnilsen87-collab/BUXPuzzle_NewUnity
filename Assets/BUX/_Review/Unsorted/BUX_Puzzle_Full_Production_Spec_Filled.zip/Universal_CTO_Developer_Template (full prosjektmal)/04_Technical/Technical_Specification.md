# Technical Specification

## Chosen stack

Assumption:
- Client: Unity/C# mobile game.
- Backend: lightweight service for profile, challenge, leaderboard, events, economy validation.
- Database: relational or document DB with strong indexing for users/challenges/leaderboards.
- CI/CD: Unity build pipeline + automated tests + store release workflow.
- Analytics: mobile analytics SDK with custom gameplay events.

## Engineering standards

- Gameplay core must be deterministic and unit-testable.
- Presentation must not mutate gameplay state.
- All configs versioned.
- All challenge scoring versioned.
- All economy grants centralized.
- All high-value server submissions validated.
- Feature flags for live events and challenge modes.

## Required test layers

- Core engine unit tests.
- Level config validation.
- Challenge determinism tests.
- Reward/economy tests.
- UI smoke tests.
- Device performance tests.
- Backend API tests.
