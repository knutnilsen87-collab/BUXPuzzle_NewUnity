# Technical Architecture for Full Release

## Recommendation

Use the existing match-3 engine if it already separates:
- BoardEngine / authoritative gameplay state
- BoardView / presentation bridge
- TileView / visual state
- TileInput / player input
- ResolveTrace / resolve steps
- Scoring/objectives

Keep and expand this architecture. Do not rewrite the engine unless there is no deterministic resolve model or no clean separation between logic and visuals.

## Required architecture boundaries

BoardEngine:
- owns board state, legal moves, swaps, matches, specials, blockers, objectives, scoring
- produces ResolveTrace
- deterministic from seed + move list
- no Unity animation dependencies
- testable without rendering

Presentation:
- TileView
- BoardView
- BoardResolveAnimator
- TileVisualProfileLibrary
- TileFeedbackAnimator
- CompanionAnimator
- HUD

Meta systems:
- LevelMap
- Economy
- Inventory
- Cosmetics
- BearVillage
- SocialChallenge
- Events
- Analytics

Backend/services:
- user profile
- cloud save
- challenge creation and validation
- leaderboard
- events config
- economy receipt validation if IAP exists

## Determinism

Fair challenge requires:
- seeded board generation
- deterministic cascade spawn sequence
- deterministic helper target selection
- versioned scoring rules
- versioned level config
- replay validation or move-list validation

## Suggested modules

Game.Core:
- BoardEngine
- MatchFinder
- GravityResolver
- SpecialResolver
- BlockerResolver
- ObjectiveResolver
- ScoreResolver
- SeededRandom
- ResolveTrace

Game.Presentation:
- BoardView
- TileView
- TileFeedbackAnimator
- TileVisualProfiles
- CompanionController
- HUD

Game.Progression:
- LevelCatalog
- WorldMap
- Stars
- DifficultyModel
- Unlocks

Game.Economy:
- Wallet
- Inventory
- RewardGrants
- Chests
- Cosmetics

Game.Social:
- ChallengeService
- ChallengeSeed
- LeaderboardClient
- ReplaySummary

Game.LiveOps:
- EventCatalog
- DailyPuzzle
- WeeklyLeague
- SeasonPass-like reward track if used, but avoid pay-to-win.

## Data/config first

All levels, tiles, rewards, worlds, cosmetics and events should be config-driven:
- LevelConfig
- TileCatalog
- SpecialRulesConfig
- ObjectiveConfig
- RewardTable
- CosmeticCatalog
- WorldConfig
- EventConfig

Do not hardcode level-specific behavior in scene scripts.
