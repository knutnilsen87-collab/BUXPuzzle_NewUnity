# Specified / Implemented / Validated Status

| Area | Specified | Implemented | Validated |
|---|---:|---:|---:|
| Core board | Yes | Unknown | No |
| Tile mechanics | Yes | Unknown | No |
| Specials | Yes | Unknown | No |
| Blockers/objectives | Yes | Unknown | No |
| Level progression | Yes | Unknown | No |
| Same-board challenge | Yes | No/Unknown | No |
| Companion | Yes | No/Unknown | No |
| Wardrobe/cosmetics | Yes | No/Unknown | No |
| Bear Village | Yes | No/Unknown | No |
| Economy | Yes | No/Unknown | No |
| Backend | Yes | No/Unknown | No |
| QA plan | Yes | Not executed | No |
