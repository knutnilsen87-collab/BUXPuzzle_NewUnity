# Open Questions Table

| Question | Owner | Impact | Recommendation |
|---|---|---:|---|
| Is current engine fully deterministic? | Engineering | High | Test immediately |
| Does BoardEngine already support shape detection? | Engineering | Medium | Audit specials |
| Will backend be custom or BaaS? | CTO | High | Decide before challenge implementation |
| Will IAP exist at launch? | Product | Medium | Design fair monetization carefully |
| How many launch levels are feasible? | Game design | High | Target 120–180, validate resourcing |
| What friend system will be used? | Product/Engineering | High | Platform share link first, friend graph later |
| Are assets final resolution/format? | Art | Medium | Validate mobile performance |
