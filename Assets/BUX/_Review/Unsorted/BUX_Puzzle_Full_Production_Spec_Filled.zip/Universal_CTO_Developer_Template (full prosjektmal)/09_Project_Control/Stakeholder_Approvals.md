# Stakeholder Approvals

Required approvals before production lock:
- Product direction approval.
- Tile mechanics approval.
- Economy/fairness approval.
- Social challenge rules approval.
- Visual/design direction approval.
- Technical architecture approval.
- Backend/challenge validation approval.
- QA release gate approval.
