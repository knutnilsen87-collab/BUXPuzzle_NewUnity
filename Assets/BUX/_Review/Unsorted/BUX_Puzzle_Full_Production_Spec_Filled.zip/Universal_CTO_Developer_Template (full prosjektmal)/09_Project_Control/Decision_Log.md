# Decision Log

| Date | Decision | Reason |
|---|---|---|
| 2026-05-22 | Full release target, not prototype-first | User explicitly wants complete game release only |
| 2026-05-22 | Reuse existing match-3 engine if modular | Faster and safer than rewrite |
| 2026-05-22 | Same-board challenge is signature feature | Strong differentiation and retention |
| 2026-05-22 | Bear companion is cosmetic/personality system | Adds identity without pay-to-win |
| 2026-05-22 | Cosmetics do not affect gameplay | Preserves challenge fairness |
| 2026-05-22 | Tile/objective/blocker taxonomy defined | Keeps board readable and scalable |
