# Desktop Plugin Module Notes

Not active for player product.

May be relevant for internal level editor or designer tooling later.
