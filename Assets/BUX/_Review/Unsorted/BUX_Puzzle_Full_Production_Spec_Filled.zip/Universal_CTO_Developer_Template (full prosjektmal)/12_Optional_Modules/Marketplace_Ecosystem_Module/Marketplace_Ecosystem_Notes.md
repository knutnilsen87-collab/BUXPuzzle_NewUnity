# Marketplace / Ecosystem Notes

Active only for app stores, purchases and optional cosmetics.

Rules:
- Cosmetics may be sold.
- Boosters may be sold carefully.
- Ranked/fair challenge must not allow paid advantage.
- All purchase validation server-side.
