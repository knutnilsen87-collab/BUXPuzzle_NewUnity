# Enterprise Security Module Notes

Not active.

Use standard mobile/backend security practices defined in Security Requirements.
