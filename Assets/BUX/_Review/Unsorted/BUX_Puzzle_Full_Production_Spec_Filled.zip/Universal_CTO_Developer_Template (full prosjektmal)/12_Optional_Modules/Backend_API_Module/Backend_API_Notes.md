# Backend API Module Notes

Active.

Backend supports:
- profile/cloud save
- challenge creation/submission
- leaderboard
- event config
- purchase validation if IAP exists
- economy validation for high-value grants

Backend does not need to run the full game in real time, but must validate enough challenge data to protect fair competition.
