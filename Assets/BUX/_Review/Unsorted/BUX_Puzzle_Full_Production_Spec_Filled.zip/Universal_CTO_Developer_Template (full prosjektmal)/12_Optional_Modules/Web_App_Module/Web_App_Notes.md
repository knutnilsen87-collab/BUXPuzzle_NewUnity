# Web App Module Notes

Not active for first game release.

Possible future:
- web leaderboard
- support portal
- event landing pages
