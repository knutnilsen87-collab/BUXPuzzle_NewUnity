# Data / ML Module Notes

Analytics active. ML optional.

Use analytics to:
- tune level difficulty
- find churn points
- identify unfair levels
- tune economy
- improve event participation

Do not use opaque adaptive difficulty in fair challenge boards unless clearly versioned and deterministic.
