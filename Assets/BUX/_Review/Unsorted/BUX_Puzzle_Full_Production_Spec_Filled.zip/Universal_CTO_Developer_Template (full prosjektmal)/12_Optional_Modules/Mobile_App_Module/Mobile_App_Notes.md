# Mobile App Module Notes

Active.

Requirements:
- iOS and Android support.
- Safe area handling.
- Responsive board scaling.
- Touch-friendly booster tray.
- Reduced motion setting.
- Push notification opt-in for challenges/events.
- Store compliance for IAP/ads if used.
