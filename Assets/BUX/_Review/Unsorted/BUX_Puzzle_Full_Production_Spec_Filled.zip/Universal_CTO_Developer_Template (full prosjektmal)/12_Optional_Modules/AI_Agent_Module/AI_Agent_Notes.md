# AI Agent Module Notes

Not required for shipped game.

Possible internal use:
- level design assistance
- QA checklist generation
- analytics review
- copy generation

Do not put generative AI into player-facing gameplay for launch unless a separate safety/privacy plan exists.
