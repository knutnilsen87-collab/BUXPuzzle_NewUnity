# Optional Modules

Active:
- Mobile App
- Backend API
- Data/Analytics
- Marketplace/App Store

Inactive for launch:
- AI Agent
- Desktop Plugin
- Enterprise Security
- Web App
