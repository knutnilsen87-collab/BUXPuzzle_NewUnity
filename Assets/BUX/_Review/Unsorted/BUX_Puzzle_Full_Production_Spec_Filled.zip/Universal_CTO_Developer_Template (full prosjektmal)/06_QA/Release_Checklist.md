# Release Checklist

## Product

- Main journey complete.
- Daily Puzzle live.
- Friend Challenge live.
- Weekly League live.
- Bear Village live.
- Wardrobe live.
- First event live.

## Technical

- Crash-free target met.
- Performance target met.
- Backend stable.
- Analytics verified.
- Cloud save verified.
- Challenge validation verified.
- Economy audit complete.

## QA

- Regression pass complete.
- Device matrix complete.
- Store compliance complete.
- Accessibility pass complete.
- Localization readiness reviewed if applicable.

## Legal/privacy

- Privacy policy ready.
- Terms ready.
- Analytics disclosures ready.
- Push notification consent clear.
- Purchase disclosures ready if IAP exists.
