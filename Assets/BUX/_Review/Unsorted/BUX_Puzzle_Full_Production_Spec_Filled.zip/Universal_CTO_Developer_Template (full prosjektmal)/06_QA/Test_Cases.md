# Test Cases

## Board

- Match 3 red berries clears only matched tiles.
- Match 4 creates rocket with correct orientation.
- Match 5 creates Rainbow Orb.
- Invalid swap reverts and does not consume move.
- Board locks input during cascade.
- No valid moves triggers shuffle.

## Blockers

- Moss Patch removed by adjacent match.
- Covered Moss takes two hits.
- Shovel removes one blocker layer.
- Bomb damages blockers in radius once.
- Rocket damages blockers on line.

## Objectives

- Basket fills from adjacent matched tiles.
- Honey Pot requires two hits.
- Acorn collect objective increments correctly.
- Objective completion triggers level complete.

## Specials

- Bomb clears 3x3 valid cells.
- Rocket clears row/column.
- Rainbow clears selected tile type.
- Rainbow Flower targets useful blockers/objectives.
- Super Berry clears cross pattern.

## Social

- Same board seed creates identical board.
- Same moves produce identical result.
- Friend challenge score comparison is correct.
- No-booster ranked mode rejects booster usage.

## Companion

- Match 3 triggers small happy.
- Match 5 triggers big cheer.
- Low moves triggers worried.
- Level complete triggers victory.
- Reaction queue does not spam.

## Economy

- Level rewards granted once.
- Challenge win rewards granted once.
- Chest minimum reward is present.
- Cosmetic unlock persists.
