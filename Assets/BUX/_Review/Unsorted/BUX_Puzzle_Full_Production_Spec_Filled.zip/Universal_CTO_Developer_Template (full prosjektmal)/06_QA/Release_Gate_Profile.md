# Release Gate Profile

## Blocker

- Crashes in core gameplay.
- Soft lock in board resolve.
- Challenge results not deterministic.
- Paid advantage in fair challenge mode.
- Economy duplication exploit.
- Loss of progress/cloud save corruption.
- App store privacy violation.

## High

- Major level balance issue in main path.
- Companion/cosmetic inventory inconsistency.
- Missing reduced motion on major effects.
- Leaderboard incorrect rank order.

## Medium

- Minor animation overlap.
- Non-critical UI clipping on rare device.
- Cosmetic preview mismatch.

## Low

- Copy polish.
- Minor reward pacing adjustment.
