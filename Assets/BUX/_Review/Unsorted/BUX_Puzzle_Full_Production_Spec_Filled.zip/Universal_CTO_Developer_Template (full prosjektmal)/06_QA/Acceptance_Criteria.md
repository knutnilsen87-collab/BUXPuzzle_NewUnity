# Acceptance Criteria

## Full release acceptance

- Main journey complete with planned worlds and levels.
- All BUX2 tile mechanics implemented or explicitly scoped as visual-only where chosen.
- Same-board challenge works deterministically.
- Challenge result explains winner clearly.
- Bear companion works on board and map.
- Wardrobe cosmetics are equipable and visible.
- Bear Village progression works.
- Daily Puzzle, Weekly League and first event work.
- Economy grants/spends are correct and logged.
- Analytics events fire correctly.
- Reduced motion mode works.
- App passes device performance and crash gates.

## Core board

- Invalid swaps revert.
- Legal swaps resolve.
- Cascades complete without soft lock.
- No input during resolve.
- Specials activate correctly.
- Blocker layers show correctly.
- Objectives update correctly.

## Social challenge

- Same seed produces same board and spawns.
- Same move list produces same result.
- Booster policy enforced.
- Expired challenges cannot be newly completed.
- Leaderboard entries are validated.

## Companion

- Reactions do not block input.
- High-priority reactions replace low-priority reactions.
- Equipped outfit appears consistently.
