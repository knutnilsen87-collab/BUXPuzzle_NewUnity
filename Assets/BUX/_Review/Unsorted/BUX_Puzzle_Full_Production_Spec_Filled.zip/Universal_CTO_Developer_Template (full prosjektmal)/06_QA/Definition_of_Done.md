# Definition of Done

A feature is done when:
- product behavior is documented
- implementation follows architecture boundaries
- unit/integration tests exist where applicable
- analytics event is added if relevant
- UI states include loading/empty/error where relevant
- reduced motion/accessibility reviewed
- no known soft lock or economy exploit
- QA has validated on target device set
- release notes/change log updated
