# Test Plan

## Test types

- Unit tests for BoardEngine.
- Determinism tests for seeded challenges.
- Integration tests for objectives/rewards.
- UI tests for level flow.
- Manual QA for animation readability.
- Performance tests on low/mid/high devices.
- Backend API tests.
- Economy exploit tests.
- Store compliance checks.

## Critical test suites

1. Swap/match/cascade.
2. Special creation/activation.
3. Blockers/objectives.
4. Shovel targeting.
5. Challenge seed determinism.
6. Scoring versioning.
7. Reward grants.
8. Companion reaction queue.
9. Wardrobe equip.
10. Map progression.
