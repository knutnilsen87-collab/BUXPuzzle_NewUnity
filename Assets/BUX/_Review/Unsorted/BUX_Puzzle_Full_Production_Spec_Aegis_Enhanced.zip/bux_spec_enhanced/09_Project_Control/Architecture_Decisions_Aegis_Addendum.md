# Architecture Decisions — Aegis Addendum

## ADR-001 — BoardEngine is canonical gameplay authority

Decision:
`BoardEngine` and core gameplay systems are the only source of truth for board state, move legality, matching, resolve, blockers, objectives, and deterministic random behavior.

Rationale:
Fair same-board challenge and large-scale level validation require deterministic, testable gameplay independent of presentation.

Consequences:
- UI and animation cannot mutate board state directly.
- Companion and cosmetics are presentation/meta only unless represented by explicit canonical tile mechanics.
- Tests and validation target core rules first.

## ADR-002 — Themes are data/assets only

Decision:
Theme packs may own visuals, fonts, UI colors, audio, VFX and board presentation mappings, but not gameplay rules.

Rationale:
Multiple themes must not create divergent rule bugs.

Consequences:
- No theme-specific BoardEngine.
- Theme configs map canonical mechanics to visuals.
- Theme validation checks references and visual clarity.

## ADR-003 — Valid move means player-executable move

Decision:
A valid move is only valid if the player can actually perform it under current board state.

Rationale:
A board that has only blocked/non-swappable "matches" is dead from the player's perspective.

Consequences:
- `HasAnyValidMove` and `ValidMoveCount` must ignore blocked/locked/non-swappable tiles.
- Hint system must use the same legality method as input.
- Solvability validation must count only executable moves.

## ADR-004 — Blocked tiles must be visually obvious

Decision:
Every blocked/locked/non-swappable tile state requires a clear theme-specific visual marker and blocked-specific feedback.

Rationale:
Players should not infer blocker state only after a failed interaction.

Consequences:
- Theme packs must define blocked/locked overlays.
- UI feedback distinguishes "invalid no-match swap" from "blocked tile".
- Release/theme validation must check blocked visual coverage.

## ADR-005 — No-dead-board invariant

Decision:
The player must never regain control on a stable board with zero player-executable moves.

Rationale:
Impossible board states create churn, frustration, and cannot be manually tested at scale.

Consequences:
- Board liveness checked after start, resolve, cascade, spawn and shuffle.
- Recovery is deterministic and bounded.
- Validation fails on unrecoverable no-move states.

## ADR-006 — Wrapper-first theme migration

Decision:
First multi-theme patch should add `ThemeDefinition` and a NatureLight wrapper referencing existing assets in place, rather than moving many assets immediately.

Rationale:
Large asset moves can break Unity references and create `.meta` churn.

Consequences:
- Asset migration becomes a later cleanup phase.
- Theme contract can be validated before restructuring art folders.

## ADR-007 — status_bundle is operational truth

Decision:
Codex must maintain `status_bundle.txt` as the current restart object after meaningful transitions.

Rationale:
Prevents context drift and false-green reporting.

Consequences:
- Every major patch updates bundle version.
- Recommended next action and fallback action are explicit.
- Success is blocked when verification is missing.
