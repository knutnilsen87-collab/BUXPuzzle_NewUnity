# Validation Gates for Codex

## Purpose

This file defines the minimum verification expected after Codex changes.

## Standard gates

### Gate A — Read-only audit

Required when starting work:
- `git status --short`;
- current branch and commit;
- Unity version;
- enabled scene;
- package/dependency state;
- current validation commands discovered.

Output:
- `status_bundle.txt`.

### Gate B — Compile gate

Required after any code change:
- Unity compile/open in the expected Unity version.
- No compiler errors.
- No missing script errors.

### Gate C — Runtime smoke gate

Required after gameplay, presentation, UI, scene, theme, input, or audio changes:
- scene loads;
- GameRoot/BoardView/TileInput present;
- level starts;
- accepted swap works;
- rejected swap works;
- no critical console errors.

### Gate D — Solvability gate

Required after board, level, tile, blocker, spawn, shuffle, or valid-move changes:
- authored levels validate;
- generated/random sample validates;
- no zero-executable-move stable boards;
- blocked moves are not counted as valid.

### Gate E — Release validation gate

Required before claiming release-readiness progress:
- release validation passes with no critical failures;
- remaining warnings documented.

### Gate F — Theme validation gate

Required after theme, art, UI config, font, audio or board visual changes:
- default theme exists;
- theme configs assigned;
- tile visuals complete;
- blocked/locked visuals present;
- HUD/modal fonts/colors assigned;
- audio refs valid or explicitly silent.

### Gate G — Visual QA gate

Required after UI/presentation/theme changes:
- screenshots or manual notes for level start;
- valid swap/cascade;
- invalid swap;
- blocked tile state;
- HUD;
- result modal;
- at least two landscape aspect ratios.

### Gate H — Clean-checkout/intended-commit gate

Required before commit/push:
- required untracked files included;
- generated/temp/log files excluded;
- validation rerun on intended file set.

## Evidence rules

Do not claim success based only on:
- historical docs;
- old logs;
- "it should work";
- successful compile without relevant runtime/visual validation.

A valid success claim needs current evidence.

## Required report fields

Every patch report should include:
- files touched;
- invariants affected;
- validation run;
- result;
- remaining risks;
- recommended next action;
- fallback action;
- repo health verdict.

## Manual visual evidence

If Codex cannot capture screenshots, it must mark visual QA as `manual_required` and provide exact manual steps.

## Failure handling

If validation fails:
1. Stop.
2. Record first blocking failure.
3. Do not continue broad implementation.
4. Recommend one focused fix or rollback.
5. Update `status_bundle.txt`.
