# Document Priority and Source of Truth

## Highest priority

1. PRD_Product_Requirements_Document.md
2. Functional_Specification.md
3. Game_Mechanics_Tile_Specification.md
4. Level_Progression_Difficulty_Model.md
5. Technical_Architecture_Spec.md
6. Acceptance_Criteria.md

## Conflict rule

If documents conflict:
1. Use the PRD for product intent.
2. Use Game Mechanics spec for tile behavior.
3. Use Technical Architecture for implementation boundaries.
4. Use QA Acceptance Criteria for release decisions.

## Deprecated wording

Any inherited template reference to prototype should be interpreted as "full release scope" for this project.


## Aegis addendum priority

When Codex is implementing the current Unity repo, also treat these as high-priority implementation-control documents:

1. `04_Technical/Gameplay_Invariants_and_Solvability_v1.md`
2. `04_Technical/Theme_Pack_Architecture_v1.md`
3. `04_Technical/Unity_Repo_Structure_and_Package_Ownership.md`
4. `06_QA/Validation_Gates_for_Codex.md`
5. `09_Project_Control/Architecture_Decisions_Aegis_Addendum.md`
6. `11_Handoffs/Aegis_Codex_Master_Execution_Prompt.md`

These do not replace the PRD. They constrain how the PRD should be implemented safely in the Unity repo.
