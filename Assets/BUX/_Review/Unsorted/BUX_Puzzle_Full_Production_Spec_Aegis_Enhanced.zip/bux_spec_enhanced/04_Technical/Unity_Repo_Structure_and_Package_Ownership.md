# Unity Repo Structure and Package Ownership

## Purpose

This document defines the recommended Unity project structure for BUX Puzzle so Codex can implement the full game without creating parallel abstractions, vague ownership, or theme-specific gameplay forks.

## Core rule

Gameplay mechanics are canonical. Presentation and themes are mappings.

```text
BoardEngine determines what happens.
Presentation shows what happened.
Themes choose how it looks and sounds.
```

## Recommended target structure

```text
Assets/
  Game/
    Core/
      Board/
      Rules/
      Resolve/
      Random/
      Tests/

    Gameplay/
      Objectives/
      Blockers/
      Specials/
      Boosters/
      Scoring/

    Levels/
      Runtime/
      Validation/
      Content/

    Presentation/
      Board/
      Tiles/
      Effects/
      Input/
      Companion/

    UI/
      HUD/
      Modals/
      Map/
      Wardrobe/
      Shared/

    Audio/
      Runtime/
      Config/

    Progression/
      Save/
      LevelMap/
      Stars/
      Unlocks/

    Economy/
      Wallet/
      Rewards/
      Inventory/
      Cosmetics/

    Social/
      Challenges/
      Leaderboards/
      Replay/

    LiveOps/
      DailyPuzzle/
      WeeklyLeague/
      Events/

    Themes/
      _Shared/
      NatureLight/
      CandyGarden/
      SpaceGrove/

    Configs/
      Shared/
      Rewards/
      Cosmetics/
      Events/

    Editor/
      Validation/
      Build/
      Tools/

    Scenes/
```

## Ownership boundaries

### `Assets/Game/Core`

Owns:
- board state;
- legal moves;
- deterministic swaps/matches;
- resolve steps;
- seeded randomness;
- stable `ResolveTrace`;
- player-executable move checks.

Must not own:
- sprites;
- fonts;
- Unity UI;
- animations;
- audio clips;
- theme assets;
- scene hierarchy.

Allowed Unity dependency:
- Prefer pure C# where practical.
- If Unity types are already present, avoid increasing dependency. Do not add rendering/UI dependencies.

### `Assets/Game/Gameplay`

Owns domain mechanics around the board:
- objectives;
- blockers;
- specials;
- boosters;
- scoring rules.

Rules:
- Mechanics are canonical and theme-agnostic.
- `Blocked`, `Moss`, `Root`, `Frozen`, etc. are gameplay states.
- Theme maps those states to visuals.

### `Assets/Game/Presentation`

Owns:
- `BoardView`;
- `TileView`;
- tile animation;
- board presentation roots;
- hint/highlight visualization;
- invalid swap feedback routing.

Must not:
- decide authoritative legality in a different way than `BoardEngine`;
- mutate board state except through approved input calls;
- own level rules.

### `Assets/Game/UI`

Owns:
- HUD;
- result modal;
- map UI;
- wardrobe UI;
- shared UI widgets.

Rules:
- UI reads gameplay/progression state.
- UI does not decide board legality or rewards independently.
- Theme can change colors/fonts/sprites through `UIThemeConfig`.

### `Assets/Game/Themes`

Owns:
- visual/audio/UI mappings per theme.

Must not own:
- match rules;
- move legality;
- scoring;
- objective completion;
- reward grants;
- level solvability.

### `Assets/Game/Editor/Validation`

Owns:
- release validation;
- runtime smoke;
- solvability validation;
- theme validation;
- build preflight checks.

Validation reports should be machine-readable where practical.

## File creation rule

Create a new file only if responsibility becomes clearer. Prefer extending an existing well-owned module when the behavior belongs there.

Good new files:
- `ThemeDefinition.cs`
- `ThemeCatalog.cs`
- `ThemeValidation.cs`
- `PlayerMoveLegality.cs` or equivalent if it centralizes duplicated logic.
- `LevelSolvabilityValidator.cs` if existing validation is too broad.

Bad new files:
- `Helpers.cs`
- `MiscUtils.cs`
- `NewBoardManager.cs`
- `NatureBoardEngine.cs`
- `ThemeGameplayRules.cs`

## Theme and level separation

Levels should reference canonical mechanics, not theme-specific art.

Good:
```json
{
  "blockerType": "moss",
  "tileType": "leaf"
}
```

Bad:
```json
{
  "spriteName": "nature_moss_green_overlay"
}
```

The theme decides which sprite represents `moss`.

## Validation placement

- Board/unit invariants: `Assets/Game/Core/Tests` or existing Unity test path.
- Editor/project validation: `Assets/Game/Editor/Validation`.
- Theme reference validation: `Assets/Game/Editor/Validation/ThemeValidation.cs`.
- Build/release validation: existing release validation, extended carefully.

## Repo health success condition

A patch is not clean success unless:
- it preserves ownership boundaries;
- it does not duplicate engine rules;
- it does not create theme-specific gameplay;
- it removes or contains obsolete paths when replacing them;
- it updates validation if it changes an invariant;
- it updates `status_bundle.txt` with evidence.
