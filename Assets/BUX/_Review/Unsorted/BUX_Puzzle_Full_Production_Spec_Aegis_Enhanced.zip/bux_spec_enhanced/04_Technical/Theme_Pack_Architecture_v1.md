# Theme Pack Architecture v1

## Purpose

BUX Puzzle should support multiple visual themes while using one shared match-3 engine.

Examples:
- NatureLight
- CandyGarden
- SpaceGrove
- IceCavern
- HoneyHarvest seasonal theme

## Core architecture decision

Themes are data/assets only. Themes must not define independent gameplay rules.

```text
One engine.
Many themes.
No theme-specific BoardEngine.
```

## Theme responsibilities

A theme may own:

- tile sprites;
- special tile sprites;
- blocker overlays;
- board background;
- board panel/surface/cell slot sprites;
- fonts;
- UI colors;
- UI sprites;
- modal/HUD styling;
- audio clips/music;
- VFX prefabs;
- animation style hints.

A theme must not own:

- swap legality;
- match detection;
- blocker HP rules;
- objective completion;
- scoring;
- reward calculation;
- seeded randomness;
- level solvability;
- challenge fairness.

## Recommended theme structure

```text
Assets/Game/Themes/
  _Shared/
    ThemeDefinition.cs
    ThemeCatalog.cs
    TileSetConfig.cs
    UIThemeConfig.cs
    BoardThemeConfig.cs
    AudioThemeConfig.cs
    VfxThemeConfig.cs

  NatureLight/
    NatureLight.theme.asset
    TileSet_NatureLight.asset
    UITheme_NatureLight.asset
    BoardTheme_NatureLight.asset
    AudioTheme_NatureLight.asset
    VfxTheme_NatureLight.asset
    Sprites/
      Tiles/
      Board/
      UI/
      Blockers/
    Audio/
    Fonts/

  CandyGarden/
    CandyGarden.theme.asset
    TileSet_CandyGarden.asset
    UITheme_CandyGarden.asset
    BoardTheme_CandyGarden.asset
    AudioTheme_CandyGarden.asset
    Sprites/
    Audio/
    Fonts/
```

## ThemeDefinition contract

Recommended ScriptableObject:

```csharp
public sealed class ThemeDefinition : ScriptableObject
{
    public string ThemeId;
    public string DisplayName;

    public TileSetConfig TileSet;
    public BoardThemeConfig Board;
    public UIThemeConfig UI;
    public AudioThemeConfig Audio;
    public VfxThemeConfig Vfx;
}
```

## ThemeCatalog contract

```csharp
public sealed class ThemeCatalog : ScriptableObject
{
    public ThemeDefinition DefaultTheme;
    public List<ThemeDefinition> Themes;
}
```

Theme selection may be based on:
- level/world;
- player choice;
- seasonal event;
- test/debug setting.

## UIThemeConfig contract

Recommended fields:

```csharp
public sealed class UIThemeConfig : ScriptableObject
{
    public Font DisplayFont;
    public Font BodyFont;

    public Color Primary;
    public Color PrimaryDark;
    public Color Accent;
    public Color CardBackground;
    public Color TextDark;
    public Color TextLight;

    public Sprite HudBadgeSprite;
    public Sprite HudPanelSprite;
    public Sprite ModalCardSprite;
    public Sprite PrimaryButtonSprite;
}
```

Rules:
- Display font is for titles and primary buttons.
- Body font is for scores, reward values, objective text, progress text, and small labels.
- Small text must prioritize readability over style.

## BoardThemeConfig contract

Recommended fields:

```csharp
public sealed class BoardThemeConfig : ScriptableObject
{
    public Sprite Background;
    public Sprite BoardPanel;
    public Sprite CellSlot;
    public Sprite CellStateNormal;
    public Sprite CellStateBlocked;
    public Sprite CellStateMoss;
    public Sprite CellStateLocked;
    public Sprite SelectionRing;
    public Sprite HintRing;
}
```

## Blocked tile visual rule

Every non-swappable cell/tile state must have a clear visual marker.

Nature theme examples:
- vines/root overlay;
- moss tint;
- locked root ring;
- darker/desaturated tile base.

Candy theme examples:
- frosting overlay;
- chocolate lock;
- sugar web.

Ice theme examples:
- ice shell;
- frost ring.

The visual mapping changes per theme. The gameplay state does not.

## Runtime wiring

Recommended dependency flow:

```text
GameRoot / ThemeService
  -> ThemeDefinition
     -> BoardView / BoardPresentationController
     -> TileView
     -> SimpleHud
     -> ResultScreenOverlay
     -> GameAudioController
```

Forbidden dependency flow:

```text
BoardEngine -> ThemeDefinition
BoardEngine -> Sprite
BoardEngine -> AudioClip
BoardEngine -> UIThemeConfig
```

## Wrapper-first migration

Do not move many existing assets in the first patch if that risks `.meta` churn or broken references.

First step:
- add `ThemeDefinition`;
- create `NatureLight.theme.asset`;
- reference existing `TileSet_NatureLight.asset` and current UI/audio config in place;
- extend validation to assert all required refs exist.

Second step:
- migrate assets into `Assets/Game/Themes/NatureLight/` only when safe.

## Addressables

Do not start with Addressables unless necessary.

Use direct ScriptableObject references for the first implementation.

Consider Addressables later when:
- themes are downloadable;
- asset size becomes large;
- seasonal content needs live delivery;
- remote config selects content.

## Theme validation

Add or extend validation to check:

- every theme has a unique `ThemeId`;
- `DefaultTheme` exists;
- all required configs are assigned;
- all core tile visual IDs have sprites;
- blocked/locked/moss/root states have visible overlays;
- UI has display and body fonts;
- audio required events have clips or explicit silent fallbacks;
- game can load level 1 with the default theme;
- missing references fail loudly.

## Success criteria

Theme architecture is successful when:
- NatureLight is loaded through `ThemeDefinition` or a safe wrapper;
- BoardEngine is unchanged and theme-agnostic;
- UI/board/audio read theme configs;
- missing theme refs are caught by validation;
- runtime smoke and release validation still pass.
