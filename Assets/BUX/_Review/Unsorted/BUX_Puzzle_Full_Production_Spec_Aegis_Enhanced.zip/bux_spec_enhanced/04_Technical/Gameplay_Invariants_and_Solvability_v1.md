# Gameplay Invariants and Solvability v1

## Purpose

This document defines hard gameplay invariants for BUX Puzzle. These rules protect the player from soft locks, unclear blocked tiles, impossible boards, and false validation passes.

## Highest-priority invariant

A valid move means a player-executable move.

Not merely:
- two adjacent cells;
- a theoretical match if all tiles could move;
- a swap involving blocked/locked/non-swappable tiles.

A valid move must be executable by the player under current board state.

## Canonical swap legality

Create or identify one canonical method:

```csharp
CanPlayerSwap(cellA, cellB)
```

or

```csharp
IsPlayerExecutableSwap(cellA, cellB)
```

It must return `true` only when:

- both cells are in bounds;
- cells are adjacent;
- both cells contain swappable/movable tiles;
- neither cell is blocked, locked, frozen, rooted, or otherwise immovable;
- no blocker state prevents the swap;
- the swap creates a valid match or valid special activation.

## Required usage

The same canonical legality method must be used by:

- player input acceptance;
- invalid swap feedback;
- hint selection;
- `HasAnyValidMove`;
- `ValidMoveCount`;
- solvability validation;
- no-move recovery;
- shuffle/rebuild guard;
- release validation.

No duplicate "valid move" logic should exist in separate systems.

## Blocked tile invariant

Blocked/locked/non-swappable tiles must be obvious before interaction.

The player should not need to tap a tile to discover that it is blocked.

Required:
- clear overlay/tint/frame for blocked state;
- blocked-specific feedback when the player tries to move it;
- hints never target blocked swaps;
- valid move count ignores blocked swaps.

## No-dead-board invariant

The player must never regain control if the stable board has zero player-executable moves.

This must be checked:

- after initial board generation;
- after level mechanics are applied;
- after each resolve/cascade completes;
- after tile spawn/refill;
- after shuffle;
- before input is re-enabled.

## Recovery order

When no executable move exists:

1. Check `HasAnyValidMove()`.
2. If false, shuffle movable cells only.
3. Preserve fixed cells, blockers, locked cells, objective objects, and blocker HP.
4. Recheck.
5. If still false after bounded attempts, refill/rebuild movable cells with deterministic seed handling.
6. If still false:
   - editor/validation: fail loudly;
   - runtime: enter safe blocked/recovery path with diagnostics, not silent play.

## Determinism requirement

All recovery must be deterministic in same-board challenge contexts.

Deterministic inputs:
- level config version;
- scoring version;
- tile rules version;
- initial seed;
- move list;
- recovery attempt count.

Forbidden:
- unversioned non-deterministic random calls in challenge resolution;
- presentation-driven resolve order;
- animation events that mutate authoritative board state.

## Level solvability levels

There are two different checks.

### Board liveness

The current stable board has at least one player-executable move.

This must always be true before player input.

### Objective solvability

The level objective is structurally possible under move limits, spawn rules, blockers, and tile distribution.

Examples:
- do not require 20 honey hits if only 2 honey objects exist and moves make it impossible;
- do not spawn required tile types at zero probability;
- do not lock all access to required blockers;
- do not require an objective that has no source.

Objective solvability is harder than board liveness and may start as editor validation plus simulation.

## Validation requirements

### Authored levels

Every `Level_*.json` or level asset must validate:

- board dimensions valid;
- objective types known;
- required tile types available in spawn table;
- blockers have known mechanics;
- starting board can be generated with at least one player-executable move;
- preferably starting board has at least two executable moves;
- blocker/objective states are visually representable by the selected theme.

### Generated/fallback levels

Generated levels must validate across many seeds:

- sample easy/normal/hard/expert bands;
- check board liveness after simulated valid moves;
- check recovery never returns zero executable moves;
- fail on repeated recovery exhaustion.

### High-level progression

For high level numbers:
- difficulty may increase;
- solvability must not degrade;
- move limits and blocker pressure must stay within validated bands;
- hard levels cannot cluster indefinitely.

## Diagnostics

Solvability failures should include:

- level id;
- world id;
- seed;
- board size;
- objective list;
- spawn table;
- blocker layout;
- valid move count;
- recovery reason;
- shuffle attempts;
- failed invariant name.

## Success criteria

A patch touching board generation or move legality is successful only when:

- invalid swaps are rejected and do not consume moves;
- blocked swaps produce blocked-specific feedback;
- `HasAnyValidMove` and `ValidMoveCount` count only executable moves;
- hints never point at blocked/non-swappable swaps;
- starting board has valid executable moves;
- post-cascade board has valid executable moves;
- no-move recovery is deterministic and bounded;
- solvability validation passes;
- runtime smoke and release validation pass.
