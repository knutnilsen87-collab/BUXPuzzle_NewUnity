# Codex Prompt — Blocked Tile and Solvability Invariants

```text
You are acting as a focused Unity gameplay-invariant engineer for BUX Puzzle.

Goal:
Ensure blocked/locked/non-swappable tiles are visually clear and never counted as valid moves, then harden board liveness so the player never receives a dead board.

Authoritative docs:
- status_bundle.txt
- 04_Technical/Gameplay_Invariants_and_Solvability_v1.md
- 04_Technical/Unity_Repo_Structure_and_Package_Ownership.md
- 06_QA/Validation_Gates_for_Codex.md
- 09_Project_Control/Architecture_Decisions_Aegis_Addendum.md

Problem:
The player may see a tile as swappable even when it is blocked/locked. If valid-move detection counts blocked swaps, validation can falsely pass while the player is stuck.

Rules:
- Do not make invalid swaps valid.
- Do not allow blocked tiles to move.
- Do not redesign unrelated UI/art.
- Do not broadly refactor BoardEngine.
- Do not duplicate move legality logic.

Implement:
1. Identify or create canonical `CanPlayerSwap` / `IsPlayerExecutableSwap`.
2. Use it for:
   - input acceptance;
   - invalid swap feedback;
   - hint move selection;
   - `HasAnyValidMove`;
   - `ValidMoveCount`;
   - shuffle/no-move guard;
   - solvability validation.
3. Make blocked/locked/non-swappable tiles visually obvious.
4. Add blocked-specific feedback, e.g. "Denne brikken er blokkert".
5. Ensure hints never point to blocked/non-swappable swaps.
6. Enforce stable board has at least one executable move before input is enabled.
7. Add/strengthen validation for authored and generated levels.

Verification:
- Unity compile/open.
- Runtime smoke.
- Solvability validation.
- Release validation.
- Manual blocked tile check.
- Manual invalid swap check.
- Hint check if hints exist.
- No console errors.

Create:
- blocked_tile_invariant_report.txt or solvability_guard_report.txt
- update status_bundle.txt with incremented bundle_version.

Success:
- Blocked tiles are visually identifiable before interaction.
- Blocked swaps give blocked-specific feedback.
- `HasAnyValidMove` and `ValidMoveCount` count only executable player moves.
- No-move recovery uses executable moves only.
- Validation passes with evidence.
```
