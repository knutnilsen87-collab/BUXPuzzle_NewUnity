# Codex Prompt — Theme Architecture First Patch

```text
You are acting as a Unity architecture engineer for BUX Puzzle.

Goal:
Implement the first safe step toward multi-theme support using one shared match-3 engine and data-driven theme packs.

Authoritative docs:
- status_bundle.txt
- 04_Technical/Unity_Repo_Structure_and_Package_Ownership.md
- 04_Technical/Theme_Pack_Architecture_v1.md
- 09_Project_Control/Architecture_Decisions_Aegis_Addendum.md

Rules:
- Do not fork gameplay logic per theme.
- BoardEngine must remain theme-agnostic.
- Themes may provide visuals, fonts, UI colors, audio, VFX, board panels, tile sprites and blocker overlays.
- Themes must not define independent swap/match/solvability/scoring/objective rules.
- Prefer data-driven ScriptableObjects.
- Keep patch small and repo-healthy.
- Wrapper-first: do not move many existing assets unless safe.

Inspect:
- Assets/Game/Content/Tiles/TileSetConfig.cs
- Assets/Game/Content/Tiles/TileSet_NatureLight.asset
- Assets/Game/Presentation/BoardView.cs
- Assets/Game/Presentation/TileView.cs
- Assets/Game/Presentation/BoardPresentationController.cs
- Assets/Game/UI/SimpleHud.cs
- Assets/Game/UI/ResultScreenOverlay.cs
- Assets/Game/Audio/GameAudioController.cs
- Assets/Game/GameRoot.cs
- existing validation scripts

Implement:
1. Add ThemeDefinition ScriptableObject.
2. Add ThemeCatalog ScriptableObject.
3. Add UIThemeConfig if no equivalent exists.
4. Add BoardThemeConfig if needed.
5. Add AudioThemeConfig if needed.
6. Create or prepare NatureLight theme references using existing assets.
7. Wire theme usage only where safe:
   - board/presentation visuals;
   - HUD/modal colors/fonts;
   - audio config.
8. Extend validation to verify required theme refs.
9. Do not alter BoardEngine mechanics.
10. Do not create Candy/Space assets yet unless complete, non-placeholder assets already exist.

Validation:
- Unity compile/open.
- Runtime smoke.
- Release validation.
- Theme validation.
- Confirm BoardEngine has no dependency on ThemeDefinition or theme assets.
- Confirm missing theme references fail validation clearly.

Create:
- theme_architecture_report.txt
- update status_bundle.txt with incremented bundle_version.

Success:
- NatureLight works through ThemeDefinition or a clear wrapper path.
- BoardEngine remains theme-agnostic.
- Missing theme refs are validated.
- Runtime smoke and release validation pass.
```
