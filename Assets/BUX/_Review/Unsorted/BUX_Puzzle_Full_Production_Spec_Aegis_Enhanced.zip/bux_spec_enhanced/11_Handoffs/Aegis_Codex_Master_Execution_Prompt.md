# Aegis Codex Master Execution Prompt

Use this prompt when giving the package and current Unity repo to Codex.

```text
You are working on BUX Puzzle, a full-release cozy forest match-3 mobile game.

Operating mode:
- AegisCode execution discipline.
- No execution without bounded plan.
- No success without verification.
- No clean success without repo-health preservation.
- Prefer the smallest safe step that creates new evidence.
- Do not perform broad rewrites.
- Update status_bundle.txt after meaningful transitions.

Read first:
1. status_bundle.txt if present in the repo.
2. MASTER_TEMPLATE_README.md
3. 00_START_HERE/Aegis_Project_Package_Analysis.md
4. 04_Technical/Technical_Architecture_Spec.md
5. 04_Technical/Unity_Repo_Structure_and_Package_Ownership.md
6. 04_Technical/Gameplay_Invariants_and_Solvability_v1.md
7. 04_Technical/Theme_Pack_Architecture_v1.md
8. 06_QA/Validation_Gates_for_Codex.md
9. 09_Project_Control/Architecture_Decisions_Aegis_Addendum.md

Core rules:
- BoardEngine is authoritative.
- BoardEngine must remain deterministic and testable.
- Presentation reacts to ResolveTrace; animations do not mutate board state.
- Themes are data/assets only and must not define gameplay rules.
- A valid move means a player-executable move.
- Blocked/locked tiles must be visually obvious.
- Player must never regain control with zero executable moves.
- Same-board challenge must use seed/config/scoring versions.
- Cosmetics must not affect gameplay power.
- Economy grants must flow through central reward/inventory services.

Before code changes:
1. Inspect repo.
2. Write/update status_bundle.txt.
3. Include:
   - facts
   - assumptions
   - ambiguity flags
   - verification state
   - repo health
   - recommended next action
   - fallback action
4. Run or identify validation commands.

Mandatory repo-health check before changes:
- correct owning folder/module?
- preserves canonical gameplay contracts?
- introduces duplicate move/rule logic?
- creates theme-specific engine behavior?
- leaves dead/obsolete UI or art wiring?
- increases coupling?
- is a new file actually justified?
- easier or harder for another engineer to understand?

Recommended first implementation sequence:
1. Verify current worktree and intended commit state.
2. Fix player-executable move semantics and blocked tile clarity.
3. Harden no-dead-board recovery and solvability validation.
4. Add ThemeDefinition wrapper around existing NatureLight assets.
5. Add theme validation.
6. Only then expand themes, levels, companion, economy, social and liveops.

Validation after relevant patches:
- Unity compile/open.
- Runtime smoke.
- Solvability validation.
- Release validation.
- Theme validation if theme/UI/art changed.
- Visual QA if presentation/UI/theme changed.
- Clean intended commit set validation before commit/push.

Stop if:
- compile fails;
- validation fails;
- valid move count diverges from input acceptance;
- hints suggest blocked/non-swappable moves;
- BoardEngine must be touched for a UI-only change;
- broad utility/misc abstractions appear;
- theme logic starts duplicating gameplay.

Patch report required:
Create a short report file named according to the patch, for example:
- blocked_tile_invariant_report.txt
- solvability_guard_report.txt
- theme_architecture_report.txt
- playful_ui_repair_report.txt

Each report must include:
- status
- files touched
- root cause
- patch applied
- invariants affected
- verification results
- repo health verdict
- recommended next action
- fallback action

Never claim the game is production-ready until all required release gates pass with current evidence.
```
