# Codex Implementation Roadmap — Safe Order

## Purpose

This is the safe execution order for Codex. It prevents broad rewrites, false green, and repo-health degradation.

## Phase 0 — Intake and status bundle

Before implementation:
1. Read docs package.
2. Inspect repo.
3. Create or update `status_bundle.txt`.
4. Run:
   - `git status --short`;
   - Unity version check;
   - compile/open if available;
   - runtime smoke if available;
   - release validation if available.

No code changes before this status bundle exists.

## Phase 1 — Current repo health and commit-scope hygiene

Goal:
Make the current local success reproducible.

Tasks:
- identify required untracked files;
- confirm clean intended commit set;
- do not reset blindly;
- validate after adding required files;
- ensure generated/log/temp folders are not treated as source.

Success:
- compile/runtime/release validation pass on intended branch/commit state.

## Phase 2 — Player-executable move invariant

Goal:
Ensure the game never counts blocked/non-swappable moves as valid.

Tasks:
- implement/identify canonical `CanPlayerSwap`;
- use it for input, hints, `HasAnyValidMove`, `ValidMoveCount`, validation;
- add blocked-specific invalid feedback;
- add blocked visual marker if absent.

Success:
- blocked tile cannot be mistaken for a normal movable tile;
- valid move detection matches what player can actually do.

## Phase 3 — Board liveness and no-dead-board recovery

Goal:
Player never regains control with zero executable moves.

Tasks:
- enforce valid move after initial generation;
- enforce valid move after resolve/cascade/spawn;
- shuffle movable cells only;
- deterministic refill/rebuild fallback;
- diagnostics and bounded attempts.

Success:
- no-move board recovers;
- editor validation fails impossible states;
- runtime never silently hands zero-move board to player.

## Phase 4 — Level solvability validation

Goal:
Authored/generated levels remain playable as content scales.

Tasks:
- validate all authored level files/assets;
- validate generated levels over many seeds;
- check objective sources;
- check spawn tables;
- check blocker constraints;
- report failures with level/seed diagnostics.

Success:
- Codex can add levels without manual playtesting every board.

## Phase 5 — Theme architecture wrapper

Goal:
Prepare multi-theme support without breaking current NatureLight setup.

Tasks:
- add `ThemeDefinition`, `ThemeCatalog`, `UIThemeConfig`, `BoardThemeConfig`, `AudioThemeConfig`;
- create NatureLight wrapper asset referencing current assets in place;
- wire theme into presentation/UI/audio where safe;
- add theme validation;
- do not move large asset folders yet.

Success:
- NatureLight still works through a theme contract;
- BoardEngine remains theme-agnostic.

## Phase 6 — Theme migration and new themes

Goal:
Safely add additional themes.

Tasks:
- create new theme folder;
- implement complete theme config;
- validate theme references;
- run visual QA;
- keep same mechanics.

Success:
- new theme can render same level with same engine rules.

## Phase 7 — Production systems

Proceed with:
- companion;
- economy;
- cosmetics;
- social same-board challenges;
- map;
- liveops;
- backend;
- analytics.

These depend on deterministic engine and canonical data contracts.

## Patch rules

Each Codex patch must include:

- bounded plan;
- target files;
- rollback path;
- validation commands;
- updated report artifact;
- updated `status_bundle.txt`;
- repo health verdict.

## Stop conditions

Stop and replan if:
- Unity compile fails;
- BoardEngine must be touched for a UI-only bug;
- theme logic starts duplicating gameplay rules;
- valid move count diverges from input acceptance;
- validation passes but visual evidence contradicts it;
- patch creates broad utility/misc files;
- repo ownership becomes ambiguous.
