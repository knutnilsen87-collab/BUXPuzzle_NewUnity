# Target Unity Repo Structure

## Recommended implementation target

```text
Assets/
  Game/
    Core/
      Board/
      Rules/
      Resolve/
      Random/
      Tests/

    Gameplay/
      Objectives/
      Blockers/
      Specials/
      Boosters/
      Scoring/

    Levels/
      Runtime/
      Content/
      Validation/

    Presentation/
      Board/
      Tiles/
      Input/
      Effects/
      Companion/

    UI/
      HUD/
      Modals/
      Shared/
      Map/
      Wardrobe/

    Themes/
      _Shared/
      NatureLight/
      CandyGarden/
      SpaceGrove/

    Audio/
      Runtime/
      Config/

    Progression/
      Save/
      LevelMap/
      Unlocks/

    Economy/
      Wallet/
      Rewards/
      Inventory/
      Cosmetics/

    Social/
      Challenges/
      Leaderboards/
      Replay/

    LiveOps/
      DailyPuzzle/
      WeeklyLeague/
      Events/

    Editor/
      Validation/
      Build/
      Tools/

    Scenes/
```

## Minimum first implementation target

Do not restructure everything in one patch. Start with:

```text
Assets/Game/Themes/
  _Shared/
    ThemeDefinition.cs
    ThemeCatalog.cs
    UIThemeConfig.cs
    BoardThemeConfig.cs
    AudioThemeConfig.cs
  NatureLight/
    NatureLight.theme.asset
```

If moving existing art assets is risky, keep them where they are and reference them from `NatureLight.theme.asset`.

## Ownership quick reference

- `Core`: rules and deterministic board truth.
- `Gameplay`: objectives, blockers, specials, scoring.
- `Presentation`: board/tile rendering and animation.
- `UI`: HUD, modals, menus.
- `Themes`: visuals/fonts/audio/colors only.
- `Levels`: level configs and validation.
- `Editor`: build and validation tools.
- `Economy`: rewards and inventory.
- `Social`: challenge and leaderboard systems.
- `LiveOps`: events/daily/weekly content.

## Anti-patterns to avoid

Avoid:
- `Helpers`;
- `Utils`;
- `Managers` with broad responsibilities;
- theme-specific engine classes;
- duplicate tile legality methods;
- scene-specific hardcoded level rules;
- visual assets referenced from core rules.
